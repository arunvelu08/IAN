<?php
/*
 * The template for displaying all single themes.
 * Author & Copyright: iangreen
 * URL: https://iangreen.com/
 */
get_header(); ?>
<div class="iangn-ele-page-wrap">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 iangn-page-col">
				<?php
				if (have_posts()) : while (have_posts()) : the_post();
					the_content();
				endwhile;
				endif;
				?>
			</div>
		</div>
	</div>
</div>
<?php get_footer();
