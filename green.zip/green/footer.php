<?php
/*
 * The template for displaying the footer.
 * Author & Copyright: iangreen
 * URL: https://iangreen.com/
 */
?>
</div><!-- Main Wrap Inner -->
<!-- Footer -->
<footer class="iangn-footer">
  	
    <div class="footer-wrap">
      <?php get_template_part( 'template-parts/footer/footer', 'widgets' ); ?>
    </div>
  	
  <?php get_template_part( 'template-parts/footer/footer', 'copyright' ); ?>
  <script src="https://cdn.jsdelivr.net/gh/stevenschobert/instafeed.js@2.0.0rc1/src/instafeed.min.js"></script>
</footer>
<!-- Footer -->
</div><!-- Main Wrap -->
<?php
wp_footer(); ?>
<nav class="iangn-fullscreen-navigation">
  <div class="navigation-wrap">
    <div class="close-btn"><a href="javascript:void(0);"></a></div>
      <?php
        wp_nav_menu(
          array(
            'menu'              => 'primary',
            'theme_location'    => 'primary',
            'container'         => 'div',
            'container_class'   => 'iangn-navigation',
            'container_id'      => '',
            'menu_class'        => '',
            'menu'              => $exertion_menubar_overlay_menu,
            'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
            'walker'            => new WP_Bootstrap_Navwalker()
          )
        );
      
      ?>
      <div class="navigation-bottom-wrap">
        <?php 
        $iangreen_custom_logo_id = get_theme_mod( 'custom_logo' );
        $iangreen_logo = wp_get_attachment_image_url( $iangreen_custom_logo_id , 'full' );
        echo '<img src="' . esc_url( $iangreen_logo ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '">'; ?>
      </div>
  </div>
</nav>
<div class="iangn-navigation-overlay"></div>
</body>
</html>
<?php
