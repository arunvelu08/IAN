<?php
global $iangreen_redux_options;
$copyright_menu = (isset($iangreen_redux_options['copyright_menu'])) ? $iangreen_redux_options['copyright_menu'] : '';
$copyright_right = (isset($iangreen_redux_options['copyright_right'])) ? $iangreen_redux_options['copyright_right'] : '';
?>
<div class="iangn-copyright alt-copyright">
  <div class="row">
    <?php if ($copyright_menu || $copyright_right) { ?>
      <div class="col-md-6">
        <?php
          echo '<nav class="footer-nav copyright-nav" data-starts="'. esc_attr($livesay_breakpoint).'">';
          wp_nav_menu(
            array(
              'menu'              => 'primary',
              'theme_location'    => 'primary',
              'container'         => '',
              'container_class'   => '',
              'container_id'      => '',
              'menu'              => $footer_menu,
              'menu_class'        => 'nav navbar-nav',
              'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
              'walker'            => new WP_Bootstrap_Navwalker()
            )
          );
          echo '</nav>';
        ?>
      </div>
      <div class="col-md-6">
      	<div class="alignright"><?php echo esc_html($copyright_right); ?></div>
      </div>
    <?php } else { ?>
      <div class="col-md-12 aligncenter">
        <p>&copy; <?php echo esc_html(date('Y')); ?>. <?php esc_html_e('Designed by', 'iangreen') ?> <a href="<?php echo esc_url(home_url( '/' )); ?>"><?php esc_html_e('iangreen', 'iangreen') ?></a></p>
      </div>
    <?php } ?>
  </div>
</div>