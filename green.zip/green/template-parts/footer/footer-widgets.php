<!-- Footer Widgets -->
<div class="row">
		<div class="col-lg-7 col-md-12 iangn-res-center">
      <?php 
      global $iangreen_redux_options;
      $footer_menu = (isset($iangreen_redux_options['footer_menu'])) ? $iangreen_redux_options['footer_menu'] : '';
      $footer_content = (isset($iangreen_redux_options['footer_content'])) ? $iangreen_redux_options['footer_content'] : '';
      $right_footer_content = (isset($iangreen_redux_options['right_footer_content'])) ? $iangreen_redux_options['right_footer_content'] : '';
      echo '<nav class="footer-nav" data-starts="'. esc_attr($livesay_breakpoint).'">';
		  wp_nav_menu(
		    array(
		      'menu'              => 'primary',
		      'theme_location'    => 'primary',
		      'container'         => '',
		      'container_class'   => '',
		      'container_id'      => '',
		      'menu'              => $footer_menu,
		      'menu_class'        => 'nav navbar-nav',
		      'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
		      'walker'            => new WP_Bootstrap_Navwalker()
		    )
		  );
		  echo '</nav>';
		  echo '<p class="about-info">'.esc_html($footer_content).'</p>';
      ?>
    </div>

			<div class="col-lg-5 col-md-6 text-right">
	      <?php echo '<p>'.esc_html($right_footer_content).'</p>'; ?>
	    </div>
</div>
<!-- Footer Widgets -->