<?php
$iangreen_custom_logo_id = get_theme_mod( 'custom_logo' );
$iangreen_logo = wp_get_attachment_image_url( $iangreen_custom_logo_id , 'full' );
if ( has_custom_logo() ) {
	$iangreen_logo_class = ' has-logo';
} else {
	$iangreen_logo_class = '';
}
if (get_header_textcolor()) {
	$iangreen_tag_color = ' style = color:#'.get_header_textcolor().';';
} else {
	$iangreen_tag_color = '';
}
?>
<div class="iangn-brand<?php echo esc_attr($iangreen_logo_class); ?>">
	<a href="<?php echo esc_url(home_url( '/' )); ?>">
	<?php
	if (is_singular( 'plugins' )) {
      echo '<h1 class="iangn-text-logo">'. esc_html(get_the_title()) .'</h1>';
	} else {
		if ( has_custom_logo() ) {
      echo '<img src="' . esc_url( $iangreen_logo ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '">';
		} elseif (display_header_text() == true){
			if (get_bloginfo( 'name' )){
	      echo '<h1 class="iangn-text-logo">'. esc_html( get_bloginfo( 'name' ) ) .'</h1>';
	    }
	    if (get_bloginfo( 'description' )){
      	echo '<h2 class="iangn-site-tagline"'.esc_attr($iangreen_tag_color).'>'.esc_html( get_bloginfo('description') ) .'</h2>';
      }
		}
	} 
	?>
	</a>
</div>
