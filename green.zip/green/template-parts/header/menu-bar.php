<?php
global $iangreen_redux_options;
$iangreen_need_content = (isset($iangreen_redux_options['need_content'])) ? $iangreen_redux_options['need_content'] : '';
$iangreen_btn_title = (isset($iangreen_redux_options['btn_title'])) ? $iangreen_redux_options['btn_title'] : '';
$iangreen_btn_text = (isset($iangreen_redux_options['btn_text'])) ? $iangreen_redux_options['btn_text'] : '';
$iangreen_btn_link = (isset($iangreen_redux_options['btn_link'])) ? $iangreen_redux_options['btn_link'] : '';
// Search
$iangreen_search_text = (isset($iangreen_redux_options['search_text'])) ? $iangreen_redux_options['search_text'] : '';
$iangreen_search_link = (isset($iangreen_redux_options['search_link'])) ? $iangreen_redux_options['search_link'] : '';
$iangreen_search_text = $iangreen_search_text ? $iangreen_search_text : esc_html__('Property Search', 'iangreen');
$search_link = $iangreen_search_link ? '<a href="'.esc_url( $iangreen_btn_link ).'" class="iangn-header-link">'.esc_html( $iangreen_search_text ).'</a>' : '<span class="iangn-header-link">'.esc_html( $iangreen_search_text ).'</span>';

// Contact
$iangreen_contact_text = (isset($iangreen_redux_options['contact_text'])) ? $iangreen_redux_options['contact_text'] : '';
$iangreen_contact_link = (isset($iangreen_redux_options['contact_link'])) ? $iangreen_redux_options['contact_link'] : '';
$iangreen_contact_text = $iangreen_contact_text ? $iangreen_contact_text : esc_html__('Property Search', 'iangreen');
$contact_link = $iangreen_contact_link ? '<a href="'.esc_url( $iangreen_btn_link ).'" class="iangn-header-link">'.esc_html( $iangreen_contact_text ).'</a>' : '<span class="iangn-header-link">'.esc_html( $iangreen_contact_text ).'</span>';

?>
<!-- Navigation & Search -->
<div class="header-links-wrap">
  <div class="header-right-btn">
		<?php if ($iangreen_need_content) { ?>
	    <span class="header-contact-links"><?php echo $iangreen_btn_title; ?><a href="<?php echo esc_url( $iangreen_btn_link ); ?>" class="iangn-contact-link"><?php echo esc_html( $iangreen_btn_text ); ?></a></span>
	    <?php echo $search_link.$contact_link; ?>
		<?php } ?>
    <a class="toggle-link" href="javascript:void(0);"><span class="toggle-separator"></span></a>
  </div>
</div>