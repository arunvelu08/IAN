<?php
/**
 * Single Post.
 */
global $post;
$iangreen_large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
$iangreen_large_image = $iangreen_large_image[0];

// Single Theme Option
if ($iangreen_large_image) {
  $img_class = '';
} else {
  $img_class = ' no-img';
}

$cat_list = get_the_category();
$tag_list = get_the_tags();
?>
<div id="post-<?php the_ID(); ?>" <?php post_class('iangn-blog-post'); ?>>
	<div class="iangn-news-detail<?php echo esc_attr($img_class); ?>">    
    <?php if ($iangreen_large_image) { ?>
		  <div class="iangn-news"><img src="<?php echo esc_url($iangreen_large_image); ?>" alt="<?php the_title_attribute(); ?>"></div>
		<?php } ?>
		<div class="iangn-news-detail-wrap">
			<div class="iangn-news-meta">
	      <div class="row">
	        <div class="col-md-12">
	        	<h5 class="iangn-news-date">
					    <?php $iangreen_categories = get_the_category();
					    if ($iangreen_categories) { ?>
						    <span>
					        <?php foreach ( $iangreen_categories as $iangreen_category ) : ?>
					          <a href="<?php echo esc_url( get_category_link( $iangreen_category->term_id ) ); ?>"><?php echo esc_html( $iangreen_category->name ); ?></a>
					        <?php endforeach; ?>
				        </span>
			        <?php } ?>
	        		<span><?php echo esc_html(get_the_date()); ?></span>
	        	</h5>
	        </div>
	      </div>
	    </div>
	    <!-- Content -->
			<?php
			the_content();
			wp_link_pages(
					array(
						'before'           => '<div class="wp-link-pages">' . esc_html__( 'Pages:', 'iangreen' ),
			      'after'            => '</div>',
			      'link_before'      => '<span>',
			      'link_after'       => '</span>',
			      'next_or_number'   => 'number',
			      'separator'        => ' ',
			      'pagelink'         => '%',
			      'echo'             => 1
					)
				);
			?>
			<!-- Content -->
			<div class="single-news-meta">
				<div class="row align-items-center">
        	<div class="col-md-6">
		        <?php $tags = get_the_tags();
				    if ($tags) { ?>
			        <div class="news-meta-tags">
			          <span class="meta-label"><?php esc_html_e( 'Tags:', 'iangreen' ); ?></span>
					      <?php foreach ( $tags as $post_tag ) : ?>
				          <span class="meta-tag"><a href="<?php echo esc_url( get_tag_link( $post_tag->term_id ) ); ?>"><?php echo esc_html( $post_tag->name ); ?></a></span>
					      <?php endforeach; ?>
			        </div>
			      <?php } ?>
			    </div>
        	<div class="col-md-6">
        		<div class="iangn-single-share"><?php if ( function_exists( 'iangreen_single_share_option' ) ) {	echo iangreen_single_share_option(); } ?></div>
        	</div>
			  </div>
      </div>
		</div>
  </div>
	<!-- Author Info -->
	<?php	
	if (get_the_author_meta( 'url' )) {
    $author_url = get_author_posts_url( get_the_author_meta( 'ID' ) );
    $website_url = get_the_author_meta( 'url' );
    $target = 'target="_blank"';
  } else {
    $author_url = get_author_posts_url( get_the_author_meta( 'ID' ) );
    $website_url = get_author_posts_url( get_the_author_meta( 'ID' ) );
    $target = '';
  }
  $author_content = get_the_author_meta( 'description' );
  if ($author_content) {
  ?>
    <div class="iangn-author-info">
    	<div class="author-avatar">
	      <a href="<?php echo esc_url($website_url); ?>" <?php echo esc_attr($target); ?>>
	        <?php echo get_avatar( get_the_author_meta( 'ID' ), 72 ); ?>
	      </a>
	    </div>
      <div class="author-content">
        <a href="<?php echo esc_url($author_url); ?>" class="author-name"><?php echo esc_html(get_the_author_meta('first_name')).' '.esc_html(get_the_author_meta('last_name')); ?></a>
        <p><?php echo esc_html(get_the_author_meta( 'description' )); ?></p>
      </div>
    </div>
  <?php } ?>
</div><!-- #post-## -->
<?php
