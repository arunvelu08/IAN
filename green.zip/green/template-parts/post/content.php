<?php
/**
 * Template part for displaying posts.
 */
// Metabox
global $post;

$iangreen_large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
$iangreen_large_image = $iangreen_large_image[0];

if (is_sticky()) {
  $iangreen_sticky_class = ' sticky';
} else {
  $iangreen_sticky_class = '';
}
if ($iangreen_large_image) {
  $iangreen_img_class = '';
} else {
  $iangreen_img_class = ' no-img';
}
?>
<div class="iangn-news-item<?php echo esc_attr($iangreen_sticky_class.$iangreen_img_class); ?>">
	<div id="post-<?php the_ID(); ?>" <?php post_class('iangn-blog-post'); ?>>
		<?php if ($iangreen_large_image) { ?>
		  <div class="iangn-image">
		    <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_post_thumbnail(); ?></a>
		  </div>
		<?php } ?>
	  <div class="iangn-news-info">
	    <div class="iangn-news-meta">
	      <div class="row">
	        <div class="col-md-12">
	        	<h5 class="iangn-news-date">
					    <?php $iangreen_categories = get_the_category();
					    if ($iangreen_categories) { ?>
						    <span>
					        <?php foreach ( $iangreen_categories as $iangreen_category ) : ?>
					          <a href="<?php echo esc_url( get_category_link( $iangreen_category->term_id ) ); ?>"><?php echo esc_html( $iangreen_category->name ); ?></a>
					        <?php endforeach; ?>
				        </span>
			        <?php } ?>
	        		<span><?php echo esc_html(get_the_date()); ?></span>
	        	</h5>
	        	<?php the_title( '<h3 class="iangn-news-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h3>' ); ?>
	        </div>
	      </div>
	    </div>
	    <?php
				echo '<div class="iangn-news-info-content">';
				the_excerpt();
				echo '</div>';
				wp_link_pages(
					array(
						'before'           => '<div class="wp-link-pages">' . esc_html__( 'Pages:', 'iangreen' ),
			      'after'            => '</div>',
			      'link_before'      => '<span>',
			      'link_after'       => '</span>',
			      'next_or_number'   => 'number',
			      'separator'        => ' ',
			      'pagelink'         => '%',
			      'echo'             => 1
					)
				);
			?>
			<div class="row align-items-center">
        <div class="col-md-12">
			    <div class="iangn-btn-wrap">
			      <a href="<?php echo esc_url( get_permalink() ); ?>" class="iangn-btn"><?php esc_html_e( 'Read More', 'iangreen' ); ?></a>
			    </div>
			  </div>
			</div>
	  </div>
	</div>
</div>
<!-- #post-## -->
<?php
