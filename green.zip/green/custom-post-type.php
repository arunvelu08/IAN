<?php

/**
 * Initialize Custom Post Type - IAN Green Theme
 */

// Slider
$slider_base = 'slider';
$slider_base_slug = 'slider';
$slider_label = 'Slider';

// Register custom post type - Slider
register_post_type('slider',
	array(
		'labels' => array(
			'name' => $slider_label,
			'singular_name' => sprintf(esc_html__('%s Post', 'iangreen' ), $slider_label),
			'all_items' => sprintf(esc_html__('All %s', 'iangreen' ), $slider_label),
			'add_new' => esc_html__('Add New', 'iangreen') ,
			'add_new_item' => sprintf(esc_html__('Add New %s', 'iangreen' ), $slider_label),
			'edit' => esc_html__('Edit', 'iangreen') ,
			'edit_item' => sprintf(esc_html__('Edit %s', 'iangreen' ), $slider_label),
			'new_item' => sprintf(esc_html__('New %s', 'iangreen' ), $slider_label),
			'view_item' => sprintf(esc_html__('View %s', 'iangreen' ), $slider_label),
			'search_items' => sprintf(esc_html__('Search %s', 'iangreen' ), $slider_label),
			'not_found' => esc_html__('Nothing found in the Database.', 'iangreen') ,
			'not_found_in_trash' => esc_html__('Nothing found in Trash', 'iangreen') ,
			'parent_item_colon' => ''
		) ,
		'public' => true,
		'publicly_queryable' => true,
		'exclude_from_search' => false,
		'show_ui' => true,
		'query_var' => true,
		'menu_position' => 20,
		'menu_icon' => 'dashicons-admin-appearance',
		'rewrite' => array(
			'slug' => $slider_base_slug,
			'with_front' => false
		),
		'has_archive' => true,
		'capability_type' => 'post',
		'hierarchical' => true,
		'supports' => array(
			'title',
			'editor',
			'author',
			'thumbnail',
			'excerpt',
			'trackbacks',
			'custom-fields',
			'comments',
			'revisions',
			'sticky',
			'page-attributes'
		)
	)
);
// Registered

// Add Category Taxonomy for our Custom Post Type - Slider
register_taxonomy(
	'slider_category',
	'slider',
	array(
		'hierarchical' => true,
		'public' => true,
		'show_ui' => true,
		'show_admin_column' => true,
		'show_in_nav_menus' => true,
		'labels' => array(
			'name' => sprintf(esc_html__( '%s Categories', 'iangreen' ), $slider_label),
			'singular_name' => sprintf(esc_html__('%s Category', 'iangreen'), $slider_label),
			'search_items' =>  sprintf(esc_html__( 'Search %s Categories', 'iangreen'), $slider_label),
			'all_items' => sprintf(esc_html__( 'All %s Categories', 'iangreen'), $slider_label),
			'parent_item' => sprintf(esc_html__( 'Parent %s Category', 'iangreen'), $slider_label),
			'parent_item_colon' => sprintf(esc_html__( 'Parent %s Category:', 'iangreen'), $slider_label),
			'edit_item' => sprintf(esc_html__( 'Edit %s Category', 'iangreen'), $slider_label),
			'update_item' => sprintf(esc_html__( 'Update %s Category', 'iangreen'), $slider_label),
			'add_new_item' => sprintf(esc_html__( 'Add New %s Category', 'iangreen'), $slider_label),
			'new_item_name' => sprintf(esc_html__( 'New %s Category Name', 'iangreen'), $slider_label)
		),
		'rewrite' => array( 'slug' => $slider_base . '_cat' ),
	)
);

$args = array(
	'hierarchical' => true,
	'public' => true,
	'show_ui' => true,
	'show_admin_column' => true,
	'show_in_nav_menus' => true,
	'show_tagcloud' => false,
);

// Videos
$videos_base = 'videos';
$videos_base_slug = 'videos';
$videos_label = 'Videos';

// Register custom post type - Videos
register_post_type('videos',
	array(
		'labels' => array(
			'name' => $videos_label,
			'singular_name' => sprintf(esc_html__('%s Post', 'iangreen' ), $videos_label),
			'all_items' => sprintf(esc_html__('All %s', 'iangreen' ), $videos_label),
			'add_new' => esc_html__('Add New', 'iangreen') ,
			'add_new_item' => sprintf(esc_html__('Add New %s', 'iangreen' ), $videos_label),
			'edit' => esc_html__('Edit', 'iangreen') ,
			'edit_item' => sprintf(esc_html__('Edit %s', 'iangreen' ), $videos_label),
			'new_item' => sprintf(esc_html__('New %s', 'iangreen' ), $videos_label),
			'view_item' => sprintf(esc_html__('View %s', 'iangreen' ), $videos_label),
			'search_items' => sprintf(esc_html__('Search %s', 'iangreen' ), $videos_label),
			'not_found' => esc_html__('Nothing found in the Database.', 'iangreen') ,
			'not_found_in_trash' => esc_html__('Nothing found in Trash', 'iangreen') ,
			'parent_item_colon' => ''
		) ,
		'public' => true,
		'publicly_queryable' => true,
		'exclude_from_search' => false,
		'show_ui' => true,
		'query_var' => true,
		'menu_position' => 20,
		'menu_icon' => 'dashicons-video-alt3',
		'rewrite' => array(
			'slug' => $videos_base_slug,
			'with_front' => false
		),
		'has_archive' => true,
		'capability_type' => 'post',
		'hierarchical' => true,
		'supports' => array(
			'title',
			'editor',
			'author',
			'thumbnail',
			'excerpt',
			'trackbacks',
			'custom-fields',
			'comments',
			'revisions',
			'sticky',
			'page-attributes'
		)
	)
);
// Registered

// Add Category Taxonomy for our Custom Post Type - Videos
register_taxonomy(
	'videos_category',
	'videos',
	array(
		'hierarchical' => true,
		'public' => true,
		'show_ui' => true,
		'show_admin_column' => true,
		'show_in_nav_menus' => true,
		'labels' => array(
			'name' => sprintf(esc_html__( '%s Categories', 'iangreen' ), $videos_label),
			'singular_name' => sprintf(esc_html__('%s Category', 'iangreen'), $videos_label),
			'search_items' =>  sprintf(esc_html__( 'Search %s Categories', 'iangreen'), $videos_label),
			'all_items' => sprintf(esc_html__( 'All %s Categories', 'iangreen'), $videos_label),
			'parent_item' => sprintf(esc_html__( 'Parent %s Category', 'iangreen'), $videos_label),
			'parent_item_colon' => sprintf(esc_html__( 'Parent %s Category:', 'iangreen'), $videos_label),
			'edit_item' => sprintf(esc_html__( 'Edit %s Category', 'iangreen'), $videos_label),
			'update_item' => sprintf(esc_html__( 'Update %s Category', 'iangreen'), $videos_label),
			'add_new_item' => sprintf(esc_html__( 'Add New %s Category', 'iangreen'), $videos_label),
			'new_item_name' => sprintf(esc_html__( 'New %s Category Name', 'iangreen'), $videos_label)
		),
		'rewrite' => array( 'slug' => $videos_base . '_cat' ),
	)
);

$args = array(
	'hierarchical' => true,
	'public' => true,
	'show_ui' => true,
	'show_admin_column' => true,
	'show_in_nav_menus' => true,
	'show_tagcloud' => false,
);

// Testimonial
$sales_template_base = 'testimonial';
$sales_template_base_slug = 'testimonial';
$sales_template_label = 'Testimonial';

// Register custom post type - Testimonial
register_post_type('testimonial',
	array(
		'labels' => array(
			'name' => $sales_template_label,
			'singular_name' => sprintf(esc_html__('%s Post', 'iangreen' ), $sales_template_label),
			'all_items' => sprintf(esc_html__('All %s', 'iangreen' ), $sales_template_label),
			'add_new' => esc_html__('Add New', 'iangreen') ,
			'add_new_item' => sprintf(esc_html__('Add New %s', 'iangreen' ), $sales_template_label),
			'edit' => esc_html__('Edit', 'iangreen') ,
			'edit_item' => sprintf(esc_html__('Edit %s', 'iangreen' ), $sales_template_label),
			'new_item' => sprintf(esc_html__('New %s', 'iangreen' ), $sales_template_label),
			'view_item' => sprintf(esc_html__('View %s', 'iangreen' ), $sales_template_label),
			'search_items' => sprintf(esc_html__('Search %s', 'iangreen' ), $sales_template_label),
			'not_found' => esc_html__('Nothing found in the Database.', 'iangreen') ,
			'not_found_in_trash' => esc_html__('Nothing found in Trash', 'iangreen') ,
			'parent_item_colon' => ''
		) ,
		'public' => true,
		'publicly_queryable' => true,
		'exclude_from_search' => false,
		'show_ui' => true,
		'query_var' => true,
		'menu_position' => 20,
		'menu_icon' => 'dashicons-welcome-add-page',
		'rewrite' => array(
			'slug' => $sales_template_base_slug,
			'with_front' => false
		),
		'has_archive' => true,
		'capability_type' => 'post',
		'hierarchical' => true,
		'supports' => array(
			'title',
			'editor',
			'author',
			'thumbnail',
			'excerpt',
			'trackbacks',
			'custom-fields',
			'comments',
			'revisions',
			'sticky',
			'page-attributes'
		)
	)
);
// Registered

// Add Category Taxonomy for our Custom Post Type - Testimonial
register_taxonomy(
	'testimonial_category',
	'testimonial',
	array(
		'hierarchical' => true,
		'public' => true,
		'show_ui' => true,
		'show_admin_column' => true,
		'show_in_nav_menus' => true,
		'labels' => array(
			'name' => sprintf(esc_html__( '%s Categories', 'iangreen' ), $sales_template_label),
			'singular_name' => sprintf(esc_html__('%s Category', 'iangreen'), $sales_template_label),
			'search_items' =>  sprintf(esc_html__( 'Search %s Categories', 'iangreen'), $sales_template_label),
			'all_items' => sprintf(esc_html__( 'All %s Categories', 'iangreen'), $sales_template_label),
			'parent_item' => sprintf(esc_html__( 'Parent %s Category', 'iangreen'), $sales_template_label),
			'parent_item_colon' => sprintf(esc_html__( 'Parent %s Category:', 'iangreen'), $sales_template_label),
			'edit_item' => sprintf(esc_html__( 'Edit %s Category', 'iangreen'), $sales_template_label),
			'update_item' => sprintf(esc_html__( 'Update %s Category', 'iangreen'), $sales_template_label),
			'add_new_item' => sprintf(esc_html__( 'Add New %s Category', 'iangreen'), $sales_template_label),
			'new_item_name' => sprintf(esc_html__( 'New %s Category Name', 'iangreen'), $sales_template_label)
		),
		'rewrite' => array( 'slug' => $sales_template_base . '_cat' ),
	)
);

$args = array(
	'hierarchical' => true,
	'public' => true,
	'show_ui' => true,
	'show_admin_column' => true,
	'show_in_nav_menus' => true,
	'show_tagcloud' => false,
);

// Add Filter by Category in Slider Type
add_action('restrict_manage_posts', 'iangreen_filter_slider_categories');
function iangreen_filter_slider_categories() {
	global $typenow;
	$post_type = 'slider'; // Slider post type
	$taxonomy  = 'slider_category'; // Slider category taxonomy
	if ($typenow == $post_type) {
		$selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
		$info_taxonomy = get_taxonomy($taxonomy);
		wp_dropdown_categories(array(
			'show_option_all' => sprintf(esc_html__("Show All %s", 'iangreen'), $info_taxonomy->label),
			'taxonomy'        => $taxonomy,
			'name'            => $taxonomy,
			'orderby'         => 'name',
			'selected'        => $selected,
			'show_count'      => true,
			'hide_empty'      => true,
		));
	};
}

// Add Filter by Category in Videos Type
add_action('restrict_manage_posts', 'iangreen_filter_videos_categories');
function iangreen_filter_videos_categories() {
	global $typenow;
	$post_type = 'videos'; // Videos post type
	$taxonomy  = 'videos_category'; // Videos category taxonomy
	if ($typenow == $post_type) {
		$selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
		$info_taxonomy = get_taxonomy($taxonomy);
		wp_dropdown_categories(array(
			'show_option_all' => sprintf(esc_html__("Show All %s", 'iangreen'), $info_taxonomy->label),
			'taxonomy'        => $taxonomy,
			'name'            => $taxonomy,
			'orderby'         => 'name',
			'selected'        => $selected,
			'show_count'      => true,
			'hide_empty'      => true,
		));
	};
}

// Add Filter by Category in Testimonial Type
add_action('restrict_manage_posts', 'iangreen_filter_sales_template_categories');
function iangreen_filter_sales_template_categories() {
	global $typenow;
	$post_type = 'testimonial'; // Testimonial post type
	$taxonomy  = 'testimonial_category'; // Testimonial category taxonomy
	if ($typenow == $post_type) {
		$selected      = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
		$info_taxonomy = get_taxonomy($taxonomy);
		wp_dropdown_categories(array(
			'show_option_all' => sprintf(esc_html__("Show All %s", 'iangreen'), $info_taxonomy->label),
			'taxonomy'        => $taxonomy,
			'name'            => $taxonomy,
			'orderby'         => 'name',
			'selected'        => $selected,
			'show_count'      => true,
			'hide_empty'      => true,
		));
	};
}

// Slider Search => ID to Term
add_filter('parse_query', 'iangreen_slider_id_term_search');
function iangreen_slider_id_term_search($query) {
	global $pagenow;
	$post_type = 'slider'; // Slider post type
	$taxonomy  = 'slider_category'; // Slider category taxonomy
	$q_vars    = &$query->query_vars;
	if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
		$term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
		$q_vars[$taxonomy] = $term->slug;
	}
}

// Videos Search => ID to Term
add_filter('parse_query', 'iangreen_videos_id_term_search');
function iangreen_videos_id_term_search($query) {
	global $pagenow;
	$post_type = 'videos'; // Videos post type
	$taxonomy  = 'videos_category'; // Videos category taxonomy
	$q_vars    = &$query->query_vars;
	if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
		$term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
		$q_vars[$taxonomy] = $term->slug;
	}
}

// Testimonial Search => ID to Term
add_filter('parse_query', 'iangreen_sales_template_id_term_search');
function iangreen_sales_template_id_term_search($query) {
	global $pagenow;
	$post_type = 'testimonial'; // Testimonial post type
	$taxonomy  = 'testimonial_category'; // Testimonial category taxonomy
	$q_vars    = &$query->query_vars;
	if ( $pagenow == 'edit.php' && isset($q_vars['post_type']) && $q_vars['post_type'] == $post_type && isset($q_vars[$taxonomy]) && is_numeric($q_vars[$taxonomy]) && $q_vars[$taxonomy] != 0 ) {
		$term = get_term_by('id', $q_vars[$taxonomy], $taxonomy);
		$q_vars[$taxonomy] = $term->slug;
	}
}

/* ---------------------------------------------------------------------------
 * Custom columns - Slider
 * --------------------------------------------------------------------------- */
add_filter("manage_edit-slider_columns", "iangreen_slider_edit_columns");
function iangreen_slider_edit_columns($columns) {
  $new_columns['cb'] = '<input type="checkbox" />';
  $new_columns['title'] = __('Title', 'iangreen' );
  $new_columns['thumbnail'] = __('Image', 'iangreen' );
  $new_columns['slider_category'] = __('Categories', 'iangreen' );
  $new_columns['slider_order'] = __('Order', 'iangreen' );
  $new_columns['date'] = __('Date', 'iangreen' );

  return $new_columns;
}
add_action('manage_slider_posts_custom_column', 'iangreen_manage_slider_columns', 10, 2);
function iangreen_manage_slider_columns( $column_name ) {
  global $post;

  switch ($column_name) {

    /* If displaying the 'Image' column. */
    case 'thumbnail':
      echo get_the_post_thumbnail( $post->ID, array( 100, 100) );
    break;

    /* If displaying the 'Categories' column. */
    case 'slider_category' :

      $terms = get_the_terms( $post->ID, 'slider_category' );

      if ( !empty( $terms ) ) {

        $out = array();
        foreach ( $terms as $term ) {
            $out[] = sprintf( '<a href="%s">%s</a>',
            	esc_url( add_query_arg( array( 'post_type' => $post->post_type, 'slider_category' => $term->slug ), 'edit.php' ) ),
            	esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'slider_category', 'display' ) )
            );
        }
        /* Join the terms, separating them with a comma. */
        echo join( ', ', $out );
      }

      /* If no terms were found, output a default message. */
      else {
        echo '&macr;';
      }

    break;

    case "slider_order":
      echo $post->menu_order;
    break;

    /* Just break out of the switch statement for everything else. */
    default :
      break;
    break;

  }
}

/* ---------------------------------------------------------------------------
 * Custom columns - Videos
 * --------------------------------------------------------------------------- */
add_filter("manage_edit-videos_columns", "iangreen_videos_edit_columns");
function iangreen_videos_edit_columns($columns) {
  $new_columns['cb'] = '<input type="checkbox" />';
  $new_columns['title'] = __('Title', 'iangreen' );
  $new_columns['thumbnail'] = __('Image', 'iangreen' );
  $new_columns['videos_category'] = __('Categories', 'iangreen' );
  $new_columns['videos_order'] = __('Order', 'iangreen' );
  $new_columns['date'] = __('Date', 'iangreen' );

  return $new_columns;
}
add_action('manage_videos_posts_custom_column', 'iangreen_manage_videos_columns', 10, 2);
function iangreen_manage_videos_columns( $column_name ) {
  global $post;

  switch ($column_name) {

    /* If displaying the 'Image' column. */
    case 'thumbnail':
      echo get_the_post_thumbnail( $post->ID, array( 100, 100) );
    break;

    /* If displaying the 'Categories' column. */
    case 'videos_category' :

      $terms = get_the_terms( $post->ID, 'videos_category' );

      if ( !empty( $terms ) ) {

        $out = array();
        foreach ( $terms as $term ) {
            $out[] = sprintf( '<a href="%s">%s</a>',
            	esc_url( add_query_arg( array( 'post_type' => $post->post_type, 'videos_category' => $term->slug ), 'edit.php' ) ),
            	esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'videos_category', 'display' ) )
            );
        }
        /* Join the terms, separating them with a comma. */
        echo join( ', ', $out );
      }

      /* If no terms were found, output a default message. */
      else {
        echo '&macr;';
      }

    break;

    case "videos_order":
      echo $post->menu_order;
    break;

    /* Just break out of the switch statement for everything else. */
    default :
      break;
    break;

  }
}

/* ---------------------------------------------------------------------------
 * Custom columns - Testimonial
 * --------------------------------------------------------------------------- */
add_filter("manage_edit-testimonial_columns", "iangreen_sales_template_edit_columns");
function iangreen_sales_template_edit_columns($columns) {
  $new_columns['cb'] = '<input type="checkbox" />';
  $new_columns['title'] = __('Title', 'iangreen' );
  $new_columns['thumbnail'] = __('Image', 'iangreen' );
  $new_columns['testimonial_category'] = __('Categories', 'iangreen' );
  $new_columns['testimonial_order'] = __('Order', 'iangreen' );
  $new_columns['date'] = __('Date', 'iangreen' );

  return $new_columns;
}
add_action('manage_testimonial_posts_custom_column', 'iangreen_manage_sales_template_columns', 10, 2);
function iangreen_manage_sales_template_columns( $column_name ) {
  global $post;

  switch ($column_name) {

    /* If displaying the 'Image' column. */
    case 'thumbnail':
      echo get_the_post_thumbnail( $post->ID, array( 100, 100) );
    break;

    /* If displaying the 'Categories' column. */
    case 'testimonial_category' :

      $terms = get_the_terms( $post->ID, 'testimonial_category' );

      if ( !empty( $terms ) ) {

        $out = array();
        foreach ( $terms as $term ) {
            $out[] = sprintf( '<a href="%s">%s</a>',
            	esc_url( add_query_arg( array( 'post_type' => $post->post_type, 'testimonial_category' => $term->slug ), 'edit.php' ) ),
            	esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, 'testimonial_category', 'display' ) )
            );
        }
        /* Join the terms, separating them with a comma. */
        echo join( ', ', $out );
      }

      /* If no terms were found, output a default message. */
      else {
        echo '&macr;';
      }

    break;

    case "testimonial_order":
      echo $post->menu_order;
    break;

    /* Just break out of the switch statement for everything else. */
    default :
      break;
    break;

  }
}