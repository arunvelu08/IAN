<?php
/**
 * ReduxFramework Sample Config File
 * For full documentation, please visit: http://docs.reduxframework.com/
 */

if ( ! class_exists( 'Redux' ) ) {
  return;
}

// This is your option name where all the Redux data is stored.
$iangreen_opt_name = "iangreen_redux_options";
$iangreen_opt_name = apply_filters( 'redux_demo/opt_name', $iangreen_opt_name );

// Args

$iangreen_theme = wp_get_theme();
$iangreen_args = array(
  'opt_name'             => $iangreen_opt_name,
  'display_name'         => $iangreen_theme->get( 'Name' ),
  'display_version'      => $iangreen_theme->get( 'Version' ),
  'menu_type'            => 'menu',
  'allow_sub_menu'       => true,
  'menu_title'           => __( 'iangreen', 'iangreen' ),
  'page_title'           => __( 'iangreen', 'iangreen' ),
  'google_api_key'       => '',
  'google_update_weekly' => false,
  'async_typography'     => false,
  'admin_bar'            => true,
  'admin_bar_icon'       => 'dashicons-awards',
  'admin_bar_priority'   => 50,
  'global_variable'      => '',
  'dev_mode'             => false,
  'update_notice'        => false,
  'customizer'           => true,
  'page_priority'        => '4',
  'page_parent'          => 'themes.php',
  'page_permissions'     => 'manage_options',
  'menu_icon'            => 'dashicons-awards',
  'last_tab'             => '',
  'page_icon'            => 'dashicons-awards',
  'page_slug'            => '',
  'save_defaults'        => true,
  'default_show'         => false,
  'default_mark'         => '',
  'show_import_export'   => true,
  'transient_time'       => 60 * MINUTE_IN_SECONDS,
  'output'               => true,
  'output_tag'           => true,
  'database'             => '',
  'use_cdn'              => true,

);
Redux::setArgs( $iangreen_opt_name, $iangreen_args );

// Header Parent
Redux::setSection( $iangreen_opt_name, array(
  'title'            => esc_html__('Header', 'iangreen'),
  'id'               => 'theme_header_tab',
  'icon'             => 'fa fa-bars',
) );

// Normal Menu
Redux::setSection( $iangreen_opt_name, array(
  'title'  => esc_html__('Normal Menu', 'iangreen'),
  'id'     => 'header_color_section-normal',
  'icon'             => 'fa fa-crosshairs',
  'subsection'       => true,
  'fields' => array(
    
    array(
      'id'      => 'menu_info',
      'type'    => 'info',
      'style'   => 'info',
      'title'   => esc_html__('Main Menu Colors', 'iangreen'),
    ),
    array(
      'id'        => 'menu_link_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Menu Normal Color', 'iangreen'),
      'output'    => array(
        'color' => '.iangrn-navigation ul li a'
      ),
    ),
    array(
      'id'        => 'menu_link_hover_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Menu Hover (or) Active Color', 'iangreen'),
      'output'    => array(
        'color' => '.iangrn-navigation ul li a:hover, .iangrn-navigation > ul > li.active > a, .iangrn-navigation > ul > li:hover > a',
        'border-color' => '.iangrn-navigation .nav-text .nav-dots, .iangrn-navigation .nav-text .nav-dots:before, .iangrn-navigation .nav-text .nav-dots:after'
      ),
    ),
    array(
      'id'      => 'submenu_info',
      'type'    => 'info',
      'style'   => 'info',
      'title'   => esc_html__('Sub Menu Colors', 'iangreen'),
    ),
    array(
      'id'        => 'submenu_bg_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Sub Menu Background Color', 'iangreen'),
      'output'    => array(
        'background-color' => '.dropdown-nav',
        'border-bottom-color' => '.dropdown-nav:before'
      ),
    ),
    array(
      'id'        => 'submenu_link_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Sub Menu Normal Color', 'iangreen'),
      'output'    => array(
        'color' => '.iangrn-navigation ul .dropdown-nav li a'
      ),
    ),
    array(
      'id'        => 'submenu_link_hover_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Sub Menu Hover Color', 'iangreen'),
      'output'    => array(
        'color' => '.iangrn-navigation ul .dropdown-nav li a:hover'
      ),
    ),

  )
) );

// Mobile Menu
Redux::setSection( $iangreen_opt_name, array(
  'title'  => esc_html__('Mobile Menu', 'iangreen'),
  'id'     => 'header_color_section-mobile',
  'icon'             => 'fa fa-crosshairs',
  'subsection'       => true,
  'fields' => array(
    array(
      'id'      => 'mobile_menu_info',
      'type'    => 'info',
      'style'   => 'info',
      'title'   => esc_html__('Mobile Menu Colors', 'iangreen'),
    ),
    array(
      'id'        => 'mobile_menu_toggle_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Menu Toggle Color', 'iangreen'),
      'output'    => array(
        'background-color' => '.mean-container a.meanmenu-reveal span, .mean-container a.meanmenu-reveal span:before, .mean-container a.meanmenu-reveal span:after, .mean-container a.meanmenu-reveal.meanclose span:before.mean-container a.meanmenu-reveal span, .mean-container a.meanmenu-reveal span:before, .mean-container a.meanmenu-reveal span:after, .mean-container a.meanmenu-reveal.meanclose span:before',
        'border-color' => '.mean-container a.meanmenu-reveal',
      ),
    ),
    array(
      'id'        => 'mobile_menu_bg_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Menu Background Color', 'iangreen'),
      'output'    => array(
        'background-color' => '.mean-container .mean-nav'
      ),
    ),
    array(
      'id'        => 'mobile_menu_border_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Menu Border Color', 'iangreen'),
      'output'    => array(
        'background-color' => '.mean-container .dropdown-nav.normal-style .current-menu-parent > a, .mean-container .mean-nav ul li li a, .mean-nav .dropdown-nav li.active > a, .mean-container .mean-nav ul > li a'
      ),
    ),
    array(
      'id'      => 'mobile_menu_info_link',
      'type'    => 'info',
      'style'   => 'info',
      'title'   => esc_html__('Menu Link Colors', 'iangreen'),
    ),
    array(
      'id'        => 'mobile_menu_link_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Menu Normal Color', 'iangreen'),
      'output'    => array(
        'color' => '.mean-container .mean-nav ul li a'
      ),
    ),
    array(
      'id'        => 'mobile_menu_link_hover_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Menu Hover Color', 'iangreen'),
      'output'    => array(
        'color' => '.mean-container .mean-nav > ul > li:hover > a, .mean-container .mean-nav > ul > li.current-menu-ancestor > a, .mean-container .mean-nav > ul > li.active > a, .mean-container .mean-nav .dropdown-nav > li:hover > a, .mean-container .mean-nav .dropdown-nav > li.active > a'
      ),
    ),
    array(
      'id'      => 'expand_info',
      'type'    => 'info',
      'style'   => 'info',
      'title' => esc_html__('Menu Expand Color', 'iangreen'),
    ),
    array(
      'id'        => 'expand_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Expand Color', 'iangreen'),
      'output'    => array(
        'color' => '.mean-container .mean-nav ul li a.mean-expand'
      ),
    ),
    array(
      'id'        => 'expand_hover_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Expand Hover Color', 'iangreen'),
      'output'    => array(
        'color' => '.mean-container .mean-nav ul li a.mean-expand:hover, .mean-container .mean-nav ul li a.mean-expand:focus, .mean-container .mean-nav ul li:hover > a.mean-expand, .mean-container .mean-nav ul li:focus > a.mean-expand, .iangrn-header .mean-container .dropdown-nav > li:hover > a.mean-expand, .iangrn-header .mean-container .dropdown-nav > li:focus > a.mean-expand'
      ),
    ),
    array(
      'id'        => 'expand_bg_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Expand Background Color', 'iangreen'),
      'output'    => array(
        'background-color' => '.mean-container .mean-nav ul li a.mean-expand'
      ),
    ),
    array(
      'id'        => 'expand_bg_hover_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Expand Background Hover Color', 'iangreen'),
      'output'    => array(
        'background-color' => '.mean-container .mean-nav ul li a.mean-expand:hover, .mean-container .mean-nav ul li a.mean-expand:focus, .mean-container .mean-nav ul li:hover > a.mean-expand, .mean-container .mean-nav ul li:focus > a.mean-expand, .iangrn-header .mean-container .dropdown-nav > li:hover > a.mean-expand, .iangrn-header .mean-container .dropdown-nav > li:focus > a.mean-expand'
      ),
    ),
  )
) );

// Contact Link
Redux::setSection( $iangreen_opt_name, array(
  'title'  => esc_html__('Contact Link', 'iangreen'),
  'id'     => 'header_design_tab',
  'icon'   => 'fa fa-magic',
  'subsection'       => true,
  'fields' => array(
    array(
      'id'       => 'need_content',
      'type'     => 'switch',
      'title' => esc_html__('Need Header Contact', 'iangreen'),
      'default' => true,
    ),
    array(
      'id'          => 'btn_title',
      'type'        => 'text',
      'title'       => esc_html__( 'Contact Title', 'iangreen' ),
      'default' => esc_html__( 'Tell: ', 'iangreen' ),
      'required' => array( 'need_content', '=', true ),
    ),
    array(
      'id'          => 'btn_text',
      'type'        => 'text',
      'title'       => esc_html__( 'Contact Number', 'iangreen' ),
      'placeholder' => esc_html__( '020 7586 1000', 'iangreen' ),
      'required' => array( 'need_content', '=', true ),
    ),
    array(
      'id'          => 'btn_link',
      'type'        => 'text',
      'title'       => esc_html__( 'Contact Link', 'iangreen' ),
      'placeholder' => esc_html__( 'tel:02075861000', 'iangreen' ),
      'required' => array( 'need_content', '=', true ),
    ),
    array(
      'id'      => 'btnlink_info',
      'type'    => 'info',
      'style'   => 'info',
      'title' => esc_html__('Header Button Colors', 'iangreen'),
      'required' => array( 'need_content', '=', true ),
    ),
    array(
      'id'        => 'button_link_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Button Text Color', 'iangreen'),
      'output'    => array(
        'color' => '.header-right-btn .iangrn-contact-link'
      ),
      'required' => array( 'need_content', '=', true ),
    ),
    array(
      'id'        => 'button_link_hover_color',
      'type'      => 'color',
      'transparent'  => false,
      'title'     => esc_html__('Button Text Hover Color', 'iangreen'),
      'output'    => array(
        'color' => '.header-right-btn .iangrn-contact-link:hover'
      ),
      'required' => array( 'need_content', '=', true ),
    ),

    array(
      'id'      => 'search_info',
      'type'    => 'info',
      'style'   => 'info',
      'title' => esc_html__('Property Search', 'iangreen'),
      'required' => array( 'need_content', '=', true ),
    ),
    array(
      'id'          => 'search_text',
      'type'        => 'text',
      'title'       => esc_html__( 'Search Text', 'iangreen' ),
      'default' => esc_html__( 'Property Search', 'iangreen' ),
      'required' => array( 'need_content', '=', true ),
    ),
    array(
      'id'          => 'search_link',
      'type'        => 'text',
      'title'       => esc_html__( 'Search Link', 'iangreen' ),
      'placeholder' => esc_html__( '#0', 'iangreen' ),
      'required' => array( 'need_content', '=', true ),
    ),

    array(
      'id'      => 'contact_info',
      'type'    => 'info',
      'style'   => 'info',
      'title' => esc_html__('Contact', 'iangreen'),
      'required' => array( 'need_content', '=', true ),
    ),
    array(
      'id'          => 'contact_text',
      'type'        => 'text',
      'title'       => esc_html__( 'Contact Text', 'iangreen' ),
      'default' => esc_html__( 'Contact', 'iangreen' ),
      'required' => array( 'need_content', '=', true ),
    ),
    array(
      'id'          => 'contact_link',
      'type'        => 'text',
      'title'       => esc_html__( 'Contact Link', 'iangreen' ),
      'placeholder' => esc_html__( '#0', 'iangreen' ),
      'required' => array( 'need_content', '=', true ),
    ),

  )
) );

// Homepage
Redux::setSection( $iangreen_opt_name, array(
  'title'            => esc_html__('Homepage', 'iangreen'),
  'id'               => 'theme_home_tab',
  'icon'             => 'fa fa-bars',
) );

// Promise Section
Redux::setSection( $iangreen_opt_name, array(
  'title'  => esc_html__('Promise Section', 'iangreen'),
  'id'     => 'promidr_design_tab',
  'subsection'       => true,
  'icon'   => 'fa fa-thumbs-up',
  'fields' => array(
    
    array(
      'id'          => 'promise_title',
      'type'        => 'text',
      'title'       => esc_html__( 'Title', 'iangreen' ),
      'default' => esc_html__( 'My Promise ', 'iangreen' ),
    ),
    array(
      'id'          => 'left_content',
      'type'        => 'textarea',
      'title'       => esc_html__( 'Left Side Content', 'iangreen' ),
      'default' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s. ', 'iangreen' ),
    ),
    array(
      'id'          => 'right_content',
      'type'        => 'textarea',
      'title'       => esc_html__( 'Right Side Content', 'iangreen' ),
      'default' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. ', 'iangreen' ),
    ),
    array(
      'id'          => 'more_text',
      'type'        => 'text',
      'title'       => esc_html__( 'Read More Text', 'iangreen' ),
      'default' => esc_html__( 'More ', 'iangreen' ),
    ),
    array(
      'id'          => 'more_link',
      'type'        => 'text',
      'title'       => esc_html__( 'Promise Section', 'iangreen' ),
      'default' => esc_html__( '#0', 'iangreen' ),
    ),
    

  )
) );

// Videos Section
Redux::setSection( $iangreen_opt_name, array(
  'title'  => esc_html__('Videos Section', 'iangreen'),
  'id'     => 'promidr_video_tab',
  'icon'   => 'fa fa-play',
  'subsection'       => true,
  'fields' => array(
    
    array(
      'id'      => 'video_info',
      'type'    => 'info',
      'style'   => 'info',
      'title' => esc_html__('Videos Section', 'iangreen'),
    ),
    array(
      'id'          => 'videos_title',
      'type'        => 'text',
      'title'       => esc_html__( 'Title', 'iangreen' ),
      'default' => esc_html__( 'The Areas We Cover ', 'iangreen' ),
    ),
    array(
      'id'          => 'videos_content',
      'type'        => 'textarea',
      'title'       => esc_html__( 'Content', 'iangreen' ),
      'default'     => esc_html__('Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard.', 'iangreen'),
    ),

  )
) );

// Testimonial Section
Redux::setSection( $iangreen_opt_name, array(
  'title'  => esc_html__('Testimonial Section', 'iangreen'),
  'id'     => 'promidr_testi_tab',
  'icon'   => 'fa fa-quote-right',
  'subsection'       => true,
  'fields' => array(
    
    array(
      'id'          => 'testimonial_title',
      'type'        => 'text',
      'title'       => esc_html__( 'Title', 'iangreen' ),
      'default' => esc_html__( 'Testimonials ', 'iangreen' ),
    ),

  )
) );

// Property Sold Section
Redux::setSection( $iangreen_opt_name, array(
  'title'  => esc_html__('Property Sold Section', 'iangreen'),
  'id'     => 'promidr_property_sold_tab',
  'icon'   => 'fa fa-home',
  'subsection'       => true,
  'fields' => array(
    
    array(
      'id'      => 'property_info',
      'type'    => 'info',
      'style'   => 'info',
      'title' => esc_html__('Property Section', 'iangreen'),
    ),
    array(
      'id'          => 'sold_title',
      'type'        => 'text',
      'title'       => esc_html__( 'Title', 'iangreen' ),
      'default' => esc_html__( 'Over 1 Billion Worth of Property Sold ', 'iangreen' ),
    ),
    array(
      'id'          => 'sold_content',
      'type'        => 'ace_editor',
      'title'       => esc_html__( 'Content', 'iangreen' ),
      'default' => __( 'Over the last 30 years we have sold exclusive property throughout <span>Regents Park</span>, <span>Little Venice</span> and <span>St.John\'s Wood</span>', 'iangreen' ),
    ),
    array(
      'id'          => 'sold_btn_text',
      'type'        => 'text',
      'title'       => esc_html__( 'Button Text', 'iangreen' ),
      'default' => esc_html__( 'Find Out More ', 'iangreen' ),
    ),
    array(
      'id'          => 'sold_btn_link',
      'type'        => 'text',
      'title'       => esc_html__( 'Button Link', 'iangreen' ),
      'default' => esc_html__( '#0', 'iangreen' ),
    ),

    array(
      'id'      => 'property_info',
      'type'    => 'info',
      'style'   => 'info',
      'title' => esc_html__('Property Worth Section', 'iangreen'),
    ),
    array(
      'id'           => 'property_image',
      'type'         => 'media',
      'url'          => true,
      'title'        => esc_html__( 'Media w/ URL', 'your-textdomain-here' ),
      'compiler'     => 'true',
      'preview_size' => 'full',
    ),
    array(
      'id'          => 'property_title',
      'type'        => 'text',
      'title'       => esc_html__( 'Title', 'iangreen' ),
      'default' => esc_html__( 'Find Out how much your property is worth ', 'iangreen' ),
    ),
    array(
      'id'          => 'property_content',
      'type'        => 'textarea',
      'title'       => esc_html__( 'Content', 'iangreen' ),
      'default' => __( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard.', 'iangreen' ),
    ),
    array(
      'id'          => 'property_bone_txt',
      'type'        => 'text',
      'title'       => esc_html__( 'Link One Text', 'iangreen' ),
      'default' => esc_html__( 'Private Consultation ', 'iangreen' ),
    ),
    array(
      'id'          => 'property_bone_link',
      'type'        => 'text',
      'title'       => esc_html__( 'Link One Link', 'iangreen' ),
      'default' => esc_html__( '#0', 'iangreen' ),
    ),
    array(
      'id'          => 'property_btwo_txt',
      'type'        => 'text',
      'title'       => esc_html__( 'Link Two Text', 'iangreen' ),
      'default' => esc_html__( 'Speak to IAN Green', 'iangreen' ),
    ),
    array(
      'id'          => 'property_btwo_link',
      'type'        => 'text',
      'title'       => esc_html__( 'Link Two Link', 'iangreen' ),
      'default' => esc_html__( '#0', 'iangreen' ),
    ),

  )
) );

// Contact Section
Redux::setSection( $iangreen_opt_name, array(
  'title'  => esc_html__('Contact Section', 'iangreen'),
  'id'     => 'promidr_contact_tab',
  'icon'   => 'fa fa-quote-right',
  'subsection'       => true,
  'fields' => array(
    
    array(
      'id'          => 'contact_title',
      'type'        => 'text',
      'title'       => esc_html__( 'Title', 'iangreen' ),
      'default' => esc_html__( 'Let\'s Start a Conversation ', 'iangreen' ),
    ),
    array(
      'id'          => 'contact_link_title',
      'type'        => 'text',
      'title'       => esc_html__( 'Contact Link Title', 'iangreen' ),
      'default' => esc_html__( 'Tell: ', 'iangreen' ),
    ),
    array(
      'id'          => 'contact_number',
      'type'        => 'text',
      'title'       => esc_html__( 'Contact Number', 'iangreen' ),
      'default' => esc_html__( '020 7589 1000', 'iangreen' ),
    ),
    array(
      'id'          => 'contact_number_link',
      'type'        => 'text',
      'title'       => esc_html__( 'Contact Number Link', 'iangreen' ),
      'default' => esc_html__( 'tel:02075891000', 'iangreen' ),
    ),
    // Tab One
    array(
      'id'      => 'contact_tab_section',
      'type'    => 'info',
      'style'   => 'info',
      'title' => esc_html__('Tab One', 'iangreen'),
    ),
    array(
      'id'          => 'tab_title_one',
      'type'        => 'text',
      'title'       => esc_html__( 'Tab Title', 'iangreen' ),
      'default' => esc_html__( 'Private Consultation ', 'iangreen' ),
    ),
    array(
      'id'          => 'tab_content_one',
      'type'        => 'textarea',
      'title'       => esc_html__( 'Tab Content', 'iangreen' ),
      'default' => esc_html__( 'Private Consultation is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard. ', 'iangreen' ),
    ),
    array(
      'id'          => 'tab_form_shortcode',
      'type'        => 'editor',
      'title'       => esc_html__( 'Contact Form Shortcode', 'iangreen' ),
    ),
    // Tab Two
    array(
      'id'      => 'contact_tab_section_two',
      'type'    => 'info',
      'style'   => 'info',
      'title' => esc_html__('Tab Two', 'iangreen'),
    ),
    array(
      'id'          => 'tab_title_two',
      'type'        => 'text',
      'title'       => esc_html__( 'Tab Title', 'iangreen' ),
      'default' => esc_html__( 'General Enquiry ', 'iangreen' ),
    ),
    array(
      'id'          => 'tab_content_two',
      'type'        => 'textarea',
      'title'       => esc_html__( 'Tab Content', 'iangreen' ),
      'default' => esc_html__( 'General Enquiry is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard. ', 'iangreen' ),
    ),
    array(
      'id'          => 'tab_form_shortcode_two',
      'type'        => 'editor',
      'title'       => esc_html__( 'Contact Form Shortcode', 'iangreen' ),
    ),
    // Tab Three
    array(
      'id'      => 'contact_tab_section_three',
      'type'    => 'info',
      'style'   => 'info',
      'title' => esc_html__('Tab Three', 'iangreen'),
    ),
    array(
      'id'          => 'tab_title_three',
      'type'        => 'text',
      'title'       => esc_html__( 'Tab Title', 'iangreen' ),
      'default' => esc_html__( 'Property Valuation ', 'iangreen' ),
    ),
    array(
      'id'          => 'tab_content_three',
      'type'        => 'textarea',
      'title'       => esc_html__( 'Tab Content', 'iangreen' ),
      'default' => esc_html__( 'Property Valuation is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard. ', 'iangreen' ),
    ),
    array(
      'id'          => 'tab_form_shortcode_three',
      'type'        => 'editor',
      'title'       => esc_html__( 'Contact Form Shortcode', 'iangreen' ),
    ),

  )
) );

// Footer
Redux::setSection( $iangreen_opt_name, array(
  'title'            => esc_html__('Footer', 'iangreen'),
  'id'               => 'footer_section',
  'icon'             => 'fa fa-crosshairs',
) );

// Widget Block
Redux::setSection( $iangreen_opt_name, array(
  'title'  => esc_html__('Widget Block', 'iangreen'),
  'id'     => 'footer_widget_section',
  'subsection'       => true,
  'fields' => array(

    array(
      'id'             => 'footer_menu',
      'type'           => 'select',
      'title'          => esc_html__('Footer Menu', 'nicheaddons'),
      'data'           => 'menus',
    ),
    array(
      'id'          => 'footer_content',
      'type'        => 'textarea',
      'title'       => esc_html__( 'Left side Content', 'iangreen' ),
      'default' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard.', 'iangreen' ),
    ),
    array(
      'id'          => 'right_footer_content',
      'type'        => 'textarea',
      'title'       => esc_html__( 'Right side Content', 'iangreen' ),
      'default' => esc_html__( 'Site by: Starberry', 'iangreen' ),
    ),
    
  )
) );

// Copyright Block
Redux::setSection( $iangreen_opt_name, array(
  'title'  => esc_html__('Copyright Block', 'iangreen'),
  'id'     => 'copyright_section',
  'subsection'       => true,
  'fields' => array(

    array(
      'id'             => 'copyright_menu',
      'type'           => 'select',
      'title'          => esc_html__('Left Menu', 'nicheaddons'),
      'data'           => 'menus',
    ),
    array(
      'id'       => 'copyright_right',
      'type'     => 'text',
      'mode'     => 'html',
      'theme'    => 'monokai',
      'title'    => esc_html__( 'Copyright Right', 'redux-framework-demo' ),
    ),

  )
) );