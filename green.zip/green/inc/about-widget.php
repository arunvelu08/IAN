<?php
/*
About Widget
*/

// The widget class
class About_Widget extends WP_Widget {

  // Main constructor
  public function __construct() {
    $widget_details = array(
      'description' => 'Creates a about widget.'
    );
    parent::__construct( 'about_widget', 'About Widget', $widget_details );
  }

  // The widget form (for the backend )
  public function form( $instance ) {

    // Set widget defaults
    $defaults = array(
      'textarea'    => '',
      'btn_text'    => '',
      'btn_link'    => '',
    );
    
    // Parse current settings with defaults
    extract( wp_parse_args( ( array ) $instance, $defaults ) ); ?>

    <!-- Textarea Field -->
    <p>
      <label for="<?php echo esc_attr( $this->get_field_id( 'textarea' ) ); ?>"><?php _e( 'Textarea:', 'text_domain' ); ?></label>
      <textarea class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'textarea' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'textarea' ) ); ?>"><?php echo wp_kses_post( $textarea ); ?></textarea>
    </p>

    <!-- Button Text Field -->
    <p>
      <label for="<?php echo esc_attr( $this->get_field_id( 'btn_text' ) ); ?>"><?php _e( 'Button Text:', 'text_domain' ); ?></label>
      <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'btn_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'btn_text' ) ); ?>" type="text" value="<?php echo esc_attr( $btn_text ); ?>" />
    </p>

    <!-- Button Link Field -->
    <p>
      <label for="<?php echo esc_attr( $this->get_field_id( 'btn_link' ) ); ?>"><?php _e( 'Button Link:', 'text_domain' ); ?></label>
      <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'btn_link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'btn_link' ) ); ?>" type="text" value="<?php echo esc_attr( $btn_link ); ?>" />
    </p>

  <?php }

  // Update widget settings
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;
    $instance['textarea']     = isset( $new_instance['textarea'] ) ? wp_kses_post( $new_instance['textarea'] ) : '';
    $instance['btn_text']     = isset( $new_instance['btn_text'] ) ? wp_strip_all_tags( $new_instance['btn_text'] ) : '';
    $instance['btn_link']     = isset( $new_instance['btn_link'] ) ? wp_strip_all_tags( $new_instance['btn_link'] ) : '';
    return $instance;
  }

  // Display the widget
  public function widget( $args, $instance ) {

    extract( $args );

    // Check the widget options
    $textarea     = isset( $instance['textarea'] ) ? $instance['textarea'] : '';
    $btn_text     = isset( $instance['btn_text'] ) ? $instance['btn_text'] : '';
    $btn_link     = isset( $instance['btn_link'] ) ? $instance['btn_link'] : '';

    // WordPress core before_widget hook (always include )
    echo $before_widget;

    // Display the widget
    echo '<div class="iangn-about-widget">';
      if ( $textarea ) {
        echo '<p>' . $textarea . '</p>';
      }
      if ( $btn_text ) {
        echo '<div class="iangn-btn-wrap"><a href="'.esc_url($btn_link).'" class="iangn-btn">'.$btn_text.'</a></div>';
      }
    echo '</div>';

    // WordPress core after_widget hook (always include )
    echo $after_widget;

  }

}

// Register the widget
function register_about_widget() {
  register_widget( 'About_Widget' );
}
add_action( 'widgets_init', 'register_about_widget' );