<?php
/*
 * All CSS and JS files are enqueued from this file
 * Author & Copyright: iangreen
 * URL: https://iangreen.com/
 */

/**
 * Enqueue Files for FrontEnd
 */
if ( ! function_exists( 'iangreen_vt_scripts_styles' ) ) {
  function iangreen_vt_scripts_styles() {

    // Styles
    wp_enqueue_style( 'iangreen-google-fonts', '//fonts.googleapis.com/css?family=Muli:400,600,700,800|Quicksand:400,600,700&display=swap', false );

    wp_enqueue_style( 'iangreen-font-awesome', IANGREEN_CSS . '/font-awesome.min.css', array(), '4.7.1', 'all' );
    wp_enqueue_style( 'meanmenu', IANGREEN_CSS .'/meanmenu.css', array(), '2.0.7', 'all' );
    wp_enqueue_style( 'bootstrap', IANGREEN_CSS .'/bootstrap.min.css', array(), '5.0.1', 'all' );
    wp_enqueue_style( 'swiper', IANGREEN_CSS .'/swiper.min.css', array(), '3.4.0', 'all' );
    wp_enqueue_style( 'animate', IANGREEN_CSS .'/animate.min.css', array(), '3.5.1', 'all' );
    wp_enqueue_style( 'owl-carousel', IANGREEN_CSS .'/owl.carousel.min.css', array(), '2.3.4', 'all' );
    wp_enqueue_style( 'magnific-popup', IANGREEN_CSS .'/magnific-popup.min.css', array(), IANGREEN_VERSION, 'all' );
    wp_enqueue_style( 'iangreen-style', get_stylesheet_uri() );
    wp_enqueue_style( 'iangreen-styles', IANGREEN_CSS .'/styles.css', array(), '1.0.1', 'all' );

    // Scripts
    wp_enqueue_script( 'bootstrap', IANGREEN_SCRIPTS . '/bootstrap.min.js', array( 'jquery' ), '5.0.1', true );
    wp_enqueue_script( 'InstagramFeed', IANGREEN_SCRIPTS . '/InstagramFeed.min.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'plugins', IANGREEN_SCRIPTS . '/plugins.js', array( 'jquery' ), IANGREEN_VERSION, true );
    wp_enqueue_script( 'meanmenu', IANGREEN_SCRIPTS . '/jquery.meanmenu.js', array( 'jquery' ), '2.0.8', true );
    wp_enqueue_script( 'iangreen-skip-link-focus-fix', IANGREEN_SCRIPTS . '/skip-link-focus-fix.js', array(), IANGREEN_VERSION, true );
    wp_enqueue_script( 'iangreen-scripts', IANGREEN_SCRIPTS . '/scripts.js', array( 'jquery' ), IANGREEN_VERSION, true );

    // Comments
    wp_enqueue_script( 'validate', IANGREEN_SCRIPTS . '/jquery.validate.min.js', array( 'jquery' ), '1.9.0', true );
    wp_add_inline_script( 'validate', 'jQuery(document).ready(function($) {$("#commentform").validate({rules: {author: {required: true,minlength: 2},email: {required: true,email: true},comment: {required: true,minlength: 10}}});});' );

    // Responsive
    wp_enqueue_style( 'iangreen-responsive', IANGREEN_CSS .'/responsive.css', array(), '1.0.1', 'all' );

    // Adds support for pages with threaded comments
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
      wp_enqueue_script( 'comment-reply' );
    }

  }
  add_action( 'wp_enqueue_scripts', 'iangreen_vt_scripts_styles' );
}

/**
 * Enqueue Files for BackEnd
 */
if ( ! function_exists( 'iangreen_vt_admin_scripts_styles' ) ) {
  function iangreen_vt_admin_scripts_styles() {
    wp_enqueue_style( 'font-awesome', IANGREEN_CSS . '/font-awesome.min.css', array(), '4.7.0', 'all' );
  }
  add_action( 'admin_enqueue_scripts', 'iangreen_vt_admin_scripts_styles' );
}

/**
 * Apply theme's stylesheet to the visual editor.
 *
 * @uses add_editor_style() Links a stylesheet to visual editor
 * @uses get_stylesheet_uri() Returns URI of theme stylesheet
 */
function iangreen_add_editor_styles() {
  add_editor_style( get_stylesheet_uri() );
}
add_action( 'init', 'iangreen_add_editor_styles' );
