jQuery(document).ready(function($) {
  "use strict";

  $(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll >= 1) {
      $(".iangn-sticky-header").addClass("iangn-sticked");
    } else {
      $(".iangn-sticky-header").removeClass("iangn-sticked");
    }
  });

  //Xrton Add And Remove Class Script
  $('.header-links-wrap .toggle-link').on('click',function() {
    $('html').addClass('fullscreen-navigation-open');
  });
  $('.close-btn, .iangn-navigation-overlay').on('click',function() {
    $('html').removeClass('fullscreen-navigation-open');
  });

  $('.owl-carousel').each(function() {
    var $carousel = $(this);
    var $items = ($carousel.data('items') !== undefined) ? $carousel.data('items') : 2;
    var $responsive = ($carousel.data('res') !== undefined) ? $carousel.data('res') : 1;
    $carousel.owlCarousel({
      loop: true,
      items: $carousel.data('items'),
      center: true,
      margin: 10,
      dots : ($carousel.data('dots') !== undefined) ? $carousel.data('dots') : true,
      nav : ($carousel.data('nav') !== undefined) ? $carousel.data('nav') : false,
      navText: [],
      autoplay: true,
      autoplayHoverPause: true,
      responsive : {
        0 : {
          items : 1,
        },
        480 : {
          items : 1,
        },
        768 : {
          items : 1,
        },
        992 : {
          items : $responsive,
        }
      }
    });
    var totLength = $('.owl-dot', $carousel).length;
    $('.total-no', $carousel).html(totLength);
    $('.current-no', $carousel).html(totLength);
    $carousel.owlCarousel();
    $('.current-no', $carousel).html(1);
    $carousel.on('changed.owl.carousel', function(event) {
      var total_items = event.page.count;
      var currentNum = event.page.index + 1;
      $('.total-no', $carousel ).html(total_items);
      $('.current-no', $carousel).html(currentNum);
    });
  });
   
  $(window).load(function() {

    //Window Resize Script
    $(window).resize(function() {
      jQuery('.iangn-windowheight').height(jQuery(window).height());
      if (screen.width >= 768) {
        $('.iangn-parallax').jarallax ({
          speed: 0.6,
        })
      }
    });
    $(window).trigger('resize');

    //Swiper Slider Script
    var animEndEv = 'webkitAnimationEnd animationend';
    var swipermw = $('.swiper-container.mousewheel').length ? true : false;
    var swiperkb = $('.swiper-container.keyboard').length ? true : false;
    var swipercentered = $('.swiper-container.center').length ? true : false;
    var swiperautoplay = $('.swiper-container').data('autoplay');
    var swiperinterval = $('.swiper-container').data('interval'),
    swiperinterval = swiperinterval ? swiperinterval : 7000;
    swiperautoplay = swiperautoplay ? swiperinterval : false;

    //Swiper Fadeslides Script
    var autoplay = 5000000;
    var swiper = new Swiper('.fadeslides', {
      autoplayDisableOnInteraction: false,
      effect: 'fade',
      speed: 800,
      loop: true,
      paginationClickable: true,
      watchSlidesProgress: true,
      autoplay: autoplay,
      simulateTouch: false,
      nextButton: '.swiper-button-next',
      prevButton: '.swiper-button-prev',
      pagination: '.swiper-pagination',
      mousewheelControl: swipermw,
      keyboardControl: swiperkb,
      onSlideChangeStart: function(s) {
        var currentSlide = $(s.slides[s.activeIndex]);
        var elems = currentSlide.find('.animated')
        elems.each(function() {
          var $this = $(this);
          var animationType = $this.data('animation');
          $this.addClass(animationType, 100).on(animEndEv, function() {
            $this.removeClass(animationType);
          });
        });
      },
      onSlideChangeEnd: function(s) {
        var currentSlide = $(s.slides[s.activeIndex]);
      }
    });

  });
  

  $('.iangn-popup-video').magnificPopup ({
    mainClass: 'mfp-fade',
    type: 'iframe',
    closeMarkup:'<div class="mfp-close" title="%title%"></div>',
    iframe: {
      patterns: {
        youtube: {
          index: 'youtube.com/',
          id: function(url) {
            var m = url.match(/[\\?\\&]v=([^\\?\\&]+)/);
            if ( !m || !m[1] ) return null;
            return m[1];
          },
          src: 'https://www.youtube.com/embed/%id%?autoplay=1'
        },
        vimeo: {
          index: 'vimeo.com/',
          id: function(url) {
            var m = url.match(/(https?:\/\/)?(www.)?(player.)?vimeo.com\/([a-z]*\/)*([0-9]{6,11})[?]?.*/);
            if ( !m || !m[5] ) return null;
            return m[5];
          },
          src: 'https://player.vimeo.com/video/%id%?autoplay=1'
        }
      }
    }
  });

  // Mean Menu
  // var $navmenu = $('nav');
  // var $menu_starts = ($navmenu.data('nav') !== undefined) ? $navmenu.data('nav') : 1199;
  // $('.iangn-navigation').meanmenu({
  //   meanMenuContainer: '.iangn-header .iangn-header-right',
  //   meanMenuOpen: '<span></span>',
  //   meanMenuClose: '<span></span>',
  //   meanExpand: '<i class="fa fa-angle-down"></i>',
  //   meanContract: '<i class="fa fa-angle-up"></i>',
  //   meanScreenWidth: $menu_starts,
  // });
  // $(".mean-bar .dropdown-nav").each(function() {
  //   $(this).appendTo($(this).parent('.has-dropdown'));
  // });

  //iangreen Navigation Hover Script
  $('.iangn-navigation .has-dropdown').on ({
    focusin : function() {
      $(this).find('ul.dropdown-nav').first().stop(false, false).fadeIn(300);
    },
    focusout : function() {
      $(this).find('ul.dropdown-nav').first().stop(false, false).fadeOut(300);
    },
    mouseenter : function() {
      $(this).find('ul.dropdown-nav').first().stop(false, false).fadeIn(300);
    },
    mouseleave : function() {
      $(this).find('ul.dropdown-nav').first().stop(false, false).fadeOut(300);
    }
  });

});