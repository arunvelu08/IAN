<?php
/*
 * The template for displaying archive pages.
 * Author & Copyright: iangreen
 * URL: https://iangreen.com/
 */
get_header();
?>
<div id="iangn-content" class="iangn-mid-wrap iangn-post-listing">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="iangn-post-wrap">
        <?php
          if ( have_posts() ) :
            /* Start the Loop */
            while ( have_posts() ) : the_post();
              get_template_part( 'template-parts/post/content' );
            endwhile;
          else :
            get_template_part( 'template-parts/post/content', 'none' );
          endif; ?>
        </div>
        <div class="iangn-pagenavi">
          <?php
          the_posts_pagination(
            array(
              'prev_text' => '<i class="fa fa-angle-left"></i>',
              'next_text' => '<i class="fa fa-angle-right"></i>',
            )
          ); ?>
        </div>
        <?php wp_reset_postdata();  // avoid errors further down the page ?>
      </div>
    </div><!-- row -->
  </div>
</div>
<?php
get_footer();
