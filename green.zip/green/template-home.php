<?php
/*
 * Template Name: Home Page
 * Author & Copyright: iangreen
 * URL: https://iangreen.com/
 */

get_header();
?>
<div class="iangn-ele-page-wrap">
	<?php 
		global $iangreen_redux_options;
	  $slider_limit = (isset($iangreen_redux_options['slider_limit'])) ? $iangreen_redux_options['slider_limit'] : '';
	  $slider_column = (isset($iangreen_redux_options['slider_column'])) ? $iangreen_redux_options['slider_column'] : '';
	  $slider_orderby = (isset($iangreen_redux_options['slider_orderby'])) ? $iangreen_redux_options['slider_orderby'] : '';
	  $slider_order = (isset($iangreen_redux_options['slider_order'])) ? $iangreen_redux_options['slider_order'] : '';

	  // Pagination
	  global $paged;
	  if ( get_query_var( 'paged' ) )
	    $my_page = get_query_var( 'paged' );
	  else {
	    if ( get_query_var( 'page' ) )
	    $my_page = get_query_var( 'page' );
	    else
	    $my_page = 1;
	    set_query_var( 'paged', $my_page );
	    $paged = $my_page;
	  }

	  $args = array(
	    // other query params here,
	    'paged' => $my_page,
	    'post_type' => 'slider',
	    'posts_per_page' => (int)$slider_limit,
	    'orderby' => $slider_orderby,
	    'order' => $slider_order,
	  );

	  $slider_post = new \WP_Query( $args );
	  if ($slider_post->have_posts()) : ?>
  	<div class="swiper-container swiper-slides fadeslides keyboard iangn-windowheight">
		  <div class="swiper-wrapper">
	      <?php while ($slider_post->have_posts()) : $slider_post->the_post();
	      global $post;
	      $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
	      $large_image = $large_image[0];

	      $bone_text = get_post_meta( get_the_ID(), 'meta-btn-text', true );
	      $bone_link = get_post_meta( get_the_ID(), 'meta-btn-link', true );
	      $btwo_text = get_post_meta( get_the_ID(), 'meta-tbtn-text', true );
	      $btwo_link = get_post_meta( get_the_ID(), 'meta-tbtn-link', true );
	      $price = get_post_meta( get_the_ID(), 'meta-price', true );
	      $address = get_post_meta( get_the_ID(), 'meta-address', true );
	      $details = get_post_meta( get_the_ID(), 'meta-details', true );
	      $details_link = get_post_meta( get_the_ID(), 'meta-details-link', true );

	      $bone_link = $bone_link ? $bone_link : "#0";
	      $btwo_link = $btwo_link ? $btwo_link : "#0";
	      $details_link = $details_link ? $details_link : "#0";

	      
	      ?>
	      <div class="swiper-slide" style="background-image: url(<?php echo esc_url($large_image); ?>);">
          <div class="iangn-slide-cpation">
            <div class="iangn-table-wrap">
              <div class="iangn-align-wrap">
                <div class="container">
                  <div class="cpation-wrap">
                    <h2 class="cpation-title animated" data-animation="fadeInUp"><?php echo esc_attr(get_the_title()); ?></h2>
                    <div class="cpation-content animated" data-animation="fadeInUp"><p><?php the_excerpt(); ?></p></div>
                    <div class="iangn-btn-group animated" data-animation="fadeInUp">
                      <a href="<?php echo esc_url($bone_link); ?>" class="iangn-btn"><?php echo esc_html($bone_text); ?></a>
                      <a href="<?php echo esc_url($btwo_link); ?>" class="iangn-btn"><?php echo esc_html($btwo_text); ?></a>
                    </div>
                    <div class="iangn-slide-meta animated" data-animation="fadeInUp">
                      <p><span><?php echo esc_html($price); ?></span><?php echo esc_html($address); ?><a href="<?php echo esc_url($details_link); ?>"><?php echo esc_html($details); ?></a></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
	      <?php
	      endwhile; ?>

		    <?php wp_reset_postdata(); ?>
		  </div>
		  <div class="swiper-button-prev"></div>
      <div class="swiper-button-next"></div>
      <div class="swiper-pagination"></div>
	  </div>
	  <?php endif;
	?>
	<!-- Promise Wrap -->
	<div class="iangn-promise-wrap">
		<div class="container">
			<div class="row">
				<h4 class="promise-title">My Promise</h4>
				<div class="col-md-5">
					<p class="promise-left-content">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
				</div>
				<div class="col-md-7">
					<p class="promise-right-content">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
					<a href="#0" class="iangn-link">More</a>
				</div>
			</div>
		</div>
	</div>

	<!-- Videos Wrap -->
	<?php 
	$videos_title = (isset($iangreen_redux_options['videos_title'])) ? $iangreen_redux_options['videos_title'] : '';
	$videos_content = (isset($iangreen_redux_options['videos_content'])) ? $iangreen_redux_options['videos_content'] : '';
	?>
	<div class="iangn-videos-wrap">
		<div class="container">
			<div class="row">
				<div class="section-title-wrap">
					<h4 class="videos-title"><?php echo esc_html($videos_title); ?></h4>
					<p class="videos-content"><?php echo $videos_content; ?></p>
				</div>
			</div>
		</div>
		<?php 

			  // Pagination
			  global $paged;
			  if ( get_query_var( 'paged' ) )
			    $my_page = get_query_var( 'paged' );
			  else {
			    if ( get_query_var( 'page' ) )
			    $my_page = get_query_var( 'page' );
			    else
			    $my_page = 1;
			    set_query_var( 'paged', $my_page );
			    $paged = $my_page;
			  }

			  $args = array(
			    // other query params here,
			    'paged' => $my_page,
			    'post_type' => 'videos',
			    'posts_per_page' => -1,
			  );

			  $videos_post = new \WP_Query( $args );
			  if ($videos_post->have_posts()) : ?>
		  	<div class="owl-carousel" data-loop="true" data-center="true" data-items="2" data-res="2" data-dot="true">
		      <?php while ($videos_post->have_posts()) : $videos_post->the_post();
		      global $post;
		      $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
		      $large_image = $large_image[0];

		      $video_link = get_post_meta( get_the_ID(), 'meta-video-link', true );

		      $video_link = $video_link ? $video_link : "#0";

		      ?>
		      <div class="item video-items" style="background-image: url(<?php echo esc_url($large_image); ?>);">
            <div class="play-btn-wrap">
              <a href="<?php echo esc_url($video_link); ?>" class="video-btn iangn-popup-video"><i class="fa fa-play" aria-hidden="true"></i></a>
            </div>
	        </div>
		      <?php
		      endwhile; ?>

			    <?php wp_reset_postdata(); ?>
			  </div>
				  
			  <?php endif;
			?>
	</div>

	<!-- Testimonial Section -->
	<div class="iangn-testimonial-wrap">
		<div class="container">
			
			<?php 

			  // Pagination
			  global $paged;
			  if ( get_query_var( 'paged' ) )
			    $my_page = get_query_var( 'paged' );
			  else {
			    if ( get_query_var( 'page' ) )
			    $my_page = get_query_var( 'page' );
			    else
			    $my_page = 1;
			    set_query_var( 'paged', $my_page );
			    $paged = $my_page;
			  }

			  $args = array(
			    // other query params here,
			    'paged' => $my_page,
			    'post_type' => 'testimonial',
			    'posts_per_page' => -1,
			  );

			  $testimonial_title = (isset($iangreen_redux_options['testimonial_title'])) ? $iangreen_redux_options['testimonial_title'] : '';

			  $testimonial_post = new \WP_Query( $args );
			  if ($testimonial_post->have_posts()) : ?>
		  		<h4 class="testimonial-title"><?php echo esc_html($testimonial_title); ?></h4>
		  	<div class="owl-carousel" data-loop="true" data-items="1" data-dot="true" data-nav="true">
		      <?php while ($testimonial_post->have_posts()) : $testimonial_post->the_post();
		      global $post;
		      $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
		      $large_image = $large_image[0];

		      $author_address = get_post_meta( get_the_ID(), 'meta-author-address', true );

		      $author_address = $author_address ? $author_address : "";

		      ?>
		      <div class="item testimonial-items">
	          <div class="testimonial-item">
	            <div class="iangn-table-wrap">
	              <div class="iangn-align-wrap">
	                <div class="container">
                  	<?php the_excerpt(); ?>
                    <span class="cpation-title"><?php echo esc_attr(get_the_title()); ?><span class="author-address"><?php echo esc_html($author_address); ?></span></span>
	                </div>
	              </div>
	            </div>
	          </div>
	        </div>
		      <?php
		      endwhile; ?>

			    <?php wp_reset_postdata(); ?>
			  </div>
				  
			  <?php endif;
			?>
			</div>
	</div>

	<!-- Property Sold Section -->
	<?php 
	$sold_title = (isset($iangreen_redux_options['sold_title'])) ? $iangreen_redux_options['sold_title'] : '';
	$sold_content = (isset($iangreen_redux_options['sold_content'])) ? $iangreen_redux_options['sold_content'] : '';
	$sold_btn_text = (isset($iangreen_redux_options['sold_btn_text'])) ? $iangreen_redux_options['sold_btn_text'] : '';
	$sold_btn_link = (isset($iangreen_redux_options['sold_btn_link'])) ? $iangreen_redux_options['sold_btn_link'] : '';

	$property_image = (isset($iangreen_redux_options['property_image'])) ? $iangreen_redux_options['property_image'] : '';
	$property_title = (isset($iangreen_redux_options['property_title'])) ? $iangreen_redux_options['property_title'] : '';
	$property_content = (isset($iangreen_redux_options['property_content'])) ? $iangreen_redux_options['property_content'] : '';
	$property_bone_txt = (isset($iangreen_redux_options['property_bone_txt'])) ? $iangreen_redux_options['property_bone_txt'] : '';
	$property_bone_link = (isset($iangreen_redux_options['property_bone_link'])) ? $iangreen_redux_options['property_bone_link'] : '';
	$property_btwo_txt = (isset($iangreen_redux_options['property_btwo_txt'])) ? $iangreen_redux_options['property_btwo_txt'] : '';
	$property_btwo_link = (isset($iangreen_redux_options['property_btwo_link'])) ? $iangreen_redux_options['property_btwo_link'] : '';
	?>
	<div class="iangn-property-sold-wrap">
		<div class="container">
			<div class="row">
				<div class="property-inner-wrap">
					<h4 class="property-sold-title section-title"><?php echo esc_html($sold_title); ?></h4>
					<p class="property-sold-left-content"><?php echo $sold_content; ?></p>
					<a href="<?php echo esc_url($sold_btn_text); ?>" class="iangn-btn"><?php echo esc_html($sold_btn_text); ?></a>
				</div>
			</div>
		</div>
	</div>
	<div class="property-worth-wrap">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-8">
					<div class="property-image">
						<img src="<?php echo esc_url($property_image['url']); ?>">
					</div>
				</div>
				<div class="col-md-4">
					<div class="worth-box-wrap">
						<h4 class="section-title worth-title"><?php echo esc_html($property_title); ?></h4>
						<p><?php echo esc_html($property_content); ?></p>
						<a href="<?php echo esc_url($property_bone_link); ?>" class="iangn-link"><?php echo esc_html($property_bone_txt); ?></a>
						<a href="<?php echo esc_url($property_btwo_link); ?>" class="iangn-link"><?php echo esc_html($property_btwo_txt); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Instagram Feeds -->
  <!-- <div id="iangn-instagram-feed" class="instagram_feed"></div>
  <ul id="rudr_instafeed"></ul>
  <div id="instafeed">
</div> -->
	<?php if ( is_plugin_active( 'instagram-feed/instagram-feed.php' ) ) { ?>
	<div class="instagram-section">
		<div class="section-title-wrap">
			<h4 class="section-title insta-title"><?php echo esc_html('Our Instagram Stories', 'iangreen'); ?></h4>
		</div>
	  <?php echo do_shortcode('[instagram-feed]'); ?>
	</div>
<?php } ?>

	<!-- Contact Section -->
	<?php
	$contact_title = (isset($iangreen_redux_options['contact_title'])) ? $iangreen_redux_options['contact_title'] : '';
	$contact_link_title = (isset($iangreen_redux_options['contact_link_title'])) ? $iangreen_redux_options['contact_link_title'] : '';
	$contact_number = (isset($iangreen_redux_options['contact_number'])) ? $iangreen_redux_options['contact_number'] : '';
	$contact_number_link = (isset($iangreen_redux_options['contact_number_link'])) ? $iangreen_redux_options['contact_number_link'] : '';

	$tab_title_one = (isset($iangreen_redux_options['tab_title_one'])) ? $iangreen_redux_options['tab_title_one'] : '';
	$tab_content_one = (isset($iangreen_redux_options['tab_content_one'])) ? $iangreen_redux_options['tab_content_one'] : '';
	$tab_form_shortcode = (isset($iangreen_redux_options['tab_form_shortcode'])) ? $iangreen_redux_options['tab_form_shortcode'] : '';

	$tab_title_two = (isset($iangreen_redux_options['tab_title_two'])) ? $iangreen_redux_options['tab_title_two'] : '';
	$tab_content_two = (isset($iangreen_redux_options['tab_content_two'])) ? $iangreen_redux_options['tab_content_two'] : '';
	$tab_form_shortcode_two = (isset($iangreen_redux_options['tab_form_shortcode_two'])) ? $iangreen_redux_options['tab_form_shortcode_two'] : '';

	$tab_title_three = (isset($iangreen_redux_options['tab_title_three'])) ? $iangreen_redux_options['tab_title_three'] : '';
	$tab_content_three = (isset($iangreen_redux_options['tab_content_three'])) ? $iangreen_redux_options['tab_content_three'] : '';
	$tab_form_shortcode_three = (isset($iangreen_redux_options['tab_form_shortcode_three'])) ? $iangreen_redux_options['tab_form_shortcode_three'] : '';

	$tab_one = str_replace (' ', '', $tab_title_one); 
	$tab_two = str_replace (' ', '', $tab_title_two); 
	$tab_three = str_replace (' ', '', $tab_title_three); 
	?>
	<div class="contact-wrap">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="contact-title-wrap">
						<h4 class="section-title"><?php echo esc_html($contact_title); ?></h4>
						<span class="contact-link"><span><?php echo esc_html($contact_link_title); ?></span><a href="<?php echo esc_html($contact_number_link); ?>"><?php echo esc_html($contact_number); ?></a></span>
					</div>
					<ul class="nav nav-tabs" id="myTab" role="tablist">
					  <li class="nav-item" role="presentation">
					    <a class="nav-link active" id="<?php echo esc_attr($tab_one); ?>-tab" data-bs-toggle="tab" href="#<?php echo esc_attr($tab_one); ?>" role="tab" aria-controls="<?php echo esc_attr($tab_one); ?>" aria-selected="true"><?php echo esc_html($tab_title_one); ?></a>
					  </li>
					  <li class="nav-item" role="presentation">
					    <a class="nav-link" id="<?php echo esc_attr($tab_two); ?>-tab" data-bs-toggle="tab" href="#<?php echo esc_attr($tab_two); ?>" role="tab" aria-controls="<?php echo esc_attr($tab_two); ?>" aria-selected="false"><?php echo esc_html($tab_title_two); ?></a>
					  </li>
					  <li class="nav-item" role="presentation">
					    <a class="nav-link" id="<?php echo esc_attr($tab_three); ?>-tab" data-bs-toggle="tab" href="#<?php echo esc_attr($tab_three); ?>" role="tab" aria-controls="<?php echo esc_attr($tab_three); ?>" aria-selected="false"><?php echo esc_html($tab_title_three); ?></a>
					  </li>
					</ul>
				</div>
				<div class="col-md-6">
					<div class="tab-content" id="myTabContent">
					  <div class="tab-pane fade show active" id="<?php echo esc_attr($tab_one); ?>" role="tabpanel" aria-labelledby="<?php echo esc_attr($tab_one); ?>-tab">
					  	<?php echo esc_html($tab_content_one); ?>
					  	
						  	<form role="form " action="" method="">
							    <div class="form-group">
							      <label for="name"></label>
							      <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
							      <!--placing icon using a span element-->
							      <span class="icon user"></span>
							    </div>

							    <div class="form-group">
							      <label for="email"></label>
							      <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" required>
							      <span class="icon email"></span>
							    </div>

							    <div class="form-group">
							      <label for="phone"></label>
							      <input type="phone" class="form-control" id="phone" name="phone" placeholder="Your Telephone Number" required>
							      <span class="icon phone"></span>
							    </div>
							    <div class="row">
								    <div class="col-md-6">
								    	<div class="form-group">
									      <label for="date"></label>
									      <input type="date" class="form-control" id="date" name="date" placeholder="Preferred Date" required>
									      <span class="icon date"></span>
									    </div>
								    </div>
								    <div class="col-md-6">
								    	<div class="form-group">
									      <label for="time"></label>
									      <input type="time" class="form-control" id="time" name="time" placeholder="Time" required>
									      <span class="icon time"></span>
									    </div>
								    </div>
								  </div>

							    <div class="form-group">
							      <label for="sub"></label>
							      <input type="text" class="form-control" id="sub" name="sub" placeholder="Message" required>
							      <span class="icon message"></span>
							    </div>

							    <div class="col-sm-12">
							      <button type="submit" class="iangn-btn btn-default">Submit Form</button>
							    </div>
							  </form>
							
				  	</div>
					  <div class="tab-pane fade" id="<?php echo esc_attr($tab_two); ?>" role="tabpanel" aria-labelledby="<?php echo esc_attr($tab_two); ?>-tab">
					  	<?php echo esc_html($tab_content_two); ?>

					  	<form role="form " action="" method="">
							    <div class="form-group">
							      <label for="name"></label>
							      <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
							      <!--placing icon using a span element-->
							      <span class="icon user"></span>
							    </div>

							    <div class="form-group">
							      <label for="email"></label>
							      <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" required>
							      <span class="icon email"></span>
							    </div>

							    <div class="form-group">
							      <label for="phone"></label>
							      <input type="phone" class="form-control" id="phone" name="phone" placeholder="Your Telephone Number" required>
							      <span class="icon phone"></span>
							    </div>

							    <div class="form-group">
							      <label for="sub"></label>
							      <input type="text" class="form-control" id="sub" name="sub" placeholder="Message" required>
							      <span class="icon message"></span>
							    </div>

							    <div class="col-sm-12">
							      <button type="submit" class="iangn-btn btn-default">Submit Form</button>
							    </div>
							  </form>
				  	</div>
					  <div class="tab-pane fade" id="<?php echo esc_attr($tab_three); ?>" role="tabpanel" aria-labelledby="<?php echo esc_attr($tab_three); ?>-tab">
					  	<?php echo esc_html($tab_content_three); ?>
					  	<form role="form " action="" method="">
							    <div class="form-group">
							      <label for="name"></label>
							      <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
							      <!--placing icon using a span element-->
							      <span class="icon user"></span>
							    </div>

							    <div class="form-group">
							      <label for="email"></label>
							      <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" required>
							      <span class="icon email"></span>
							    </div>

							    <div class="form-group">
							      <label for="phone"></label>
							      <input type="phone" class="form-control" id="phone" name="phone" placeholder="Your Telephone Number" required>
							      <span class="icon phone"></span>
							    </div>
							    <div class="row">
								    <div class="col-md-6">
								    	<div class="form-group">
									      <label for="date"></label>
									      <input type="date" class="form-control" id="date" name="date" placeholder="Preferred Date" required>
									      <span class="icon date"></span>
									    </div>
								    </div>
								    <div class="col-md-6">
								    	<div class="form-group">
									      <label for="time"></label>
									      <input type="time" class="form-control" id="time" name="time" placeholder="Time" required>
									      <span class="icon time"></span>
									    </div>
								    </div>
								  </div>

							    <div class="form-group">
							      <label for="sub"></label>
							      <input type="text" class="form-control" id="sub" name="sub" placeholder="Message" required>
							      <span class="icon message"></span>
							    </div>

							    <div class="col-sm-12">
							      <button type="submit" class="iangn-btn btn-default">Submit Form</button>
							    </div>
							  </form>
					  </div>
					</div>
				</div>
			</div>
		</div>
	</div>
	

</div>
<?php

get_footer();