<?php
/*
 * IAN Green Theme's Functions
 * Author & Copyright: iangreen
 * URL: https://iangreen.com/
 */

/**
 * Define - Folder Paths
 */
define( 'IANGREEN_THEMEROOT_PATH', get_template_directory() );
define( 'IANGREEN_THEMEROOT_URI', get_template_directory_uri() );
define( 'IANGREEN_CSS', IANGREEN_THEMEROOT_URI . '/assets/css' );
define( 'IANGREEN_IMAGES', IANGREEN_THEMEROOT_URI . '/assets/images' );
define( 'IANGREEN_SCRIPTS', IANGREEN_THEMEROOT_URI . '/assets/js' );
define( 'IANGREEN_FRAMEWORK', get_template_directory() . '/inc' );
define( 'IANGREEN_LAYOUT', get_template_directory() . '/template-parts' );

/**
 * Define - Global Theme Info's
 */
if (is_child_theme()) { // If Child Theme Active
	$iangreen_theme_child = wp_get_theme();
	$iangreen_get_parent = $iangreen_theme_child->Template;
	$iangreen_theme = wp_get_theme($iangreen_get_parent);
} else { // Parent Theme Active
	$iangreen_theme = wp_get_theme();
}
define('IANGREEN_NAME', $iangreen_theme->get( 'Name' ));
define('IANGREEN_VERSION', $iangreen_theme->get( 'Version' ));
define('IANGREEN_BRAND_URL', $iangreen_theme->get( 'AuthorURI' ));
define('IANGREEN_BRAND_NAME', $iangreen_theme->get( 'Author' ));

/**
 * All Main Files Include
 */
/* Theme All Basic Setup */
require_once( IANGREEN_FRAMEWORK . '/enqueue-files.php' );
require_once( IANGREEN_FRAMEWORK . '/configuration.php' );
require_once( IANGREEN_FRAMEWORK . '/about-widget.php' );

/* Bootstrap Menu Walker */
require_once( IANGREEN_FRAMEWORK . '/plugins/class-wp-bootstrap-navwalker.php' );

/* Install Plugins */
require_once( IANGREEN_FRAMEWORK . '/plugins/notify/activation.php' );

/* Include the TGM_Plugin_Activation class. */
require_once( IANGREEN_FRAMEWORK . '/plugins/notify/class-tgm-plugin-activation.php' );

/* Integrate - Redux Framework */
require_once( IANGREEN_FRAMEWORK .'/theme-options.php' );

/* Ccontent Width */
function iangreen_content_width() {
	if ( ! isset( $content_width ) ) $content_width = 1170;
}
add_action( 'after_setup_theme', 'iangreen_content_width', 0 );

require_once( IANGREEN_THEMEROOT_PATH . '/custom-post-type.php' );

// Slider Meta Fields
function add_custom_meta_box()
{
    add_meta_box("demo-meta-box", "Custom Meta Box", "custom_meta_box_markup", "slider", "side", "high", null);
}

add_action("add_meta_boxes", "add_custom_meta_box");

function custom_meta_box_markup($object)
{
    wp_nonce_field(basename(__FILE__), "meta-box-nonce");

    ?>
      <div>
        <label for="meta-btn-text">Button One Text</label>
        <input name="meta-btn-text" type="text" value="<?php echo get_post_meta($object->ID, "meta-btn-text", true); ?>">
        <br>
      </div>
      <div>
        <label for="meta-btn-link">Button One Link</label>
        <input name="meta-btn-link" type="text" value="<?php echo get_post_meta($object->ID, "meta-btn-link", true); ?>">
        <br>
      </div>
      <div>
        <label for="meta-tbtn-text">Button Two Text</label>
        <input name="meta-tbtn-text" type="text" value="<?php echo get_post_meta($object->ID, "meta-tbtn-text", true); ?>">
        <br>
      </div>
      <div>
        <label for="meta-tbtn-link">Button Two Link</label>
        <input name="meta-tbtn-link" type="text" value="<?php echo get_post_meta($object->ID, "meta-tbtn-link", true); ?>">
        <br>
      </div>
      <div>
        <label for="meta-price">Price</label>
        <br>
        <input name="meta-price" type="text" value="<?php echo get_post_meta($object->ID, "meta-price", true); ?>">
        <br>
      </div>

      <div>
        <label for="meta-address">Address</label>
        <br>
        <input name="meta-address" type="text" value="<?php echo get_post_meta($object->ID, "meta-address", true); ?>">
        <br>
      </div>
      <div>
        <label for="meta-details">Details Text</label>
        <br>
        <input name="meta-details" type="text" value="<?php echo get_post_meta($object->ID, "meta-details", true); ?>">
        <br>
      </div>
      <div>
        <label for="meta-details-link">Details Text Link</label>
        <br>
        <input name="meta-details-link" type="text" value="<?php echo get_post_meta($object->ID, "meta-details-link", true); ?>">
        <br>
      </div>
    <?php  
}


function save_custom_meta_box($post_id, $post, $update)
{
    if (!isset($_POST["meta-box-nonce"]) || !wp_verify_nonce($_POST["meta-box-nonce"], basename(__FILE__)))
        return $post_id;

    if(!current_user_can("edit_post", $post_id))
        return $post_id;

    if(defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
        return $post_id;

    $slug = "slider";
    if($slug != $post->post_type)
        return $post_id;

    $meta_btn_text_value = "";
    $meta_btn_link_value = "";
    $meta_tbtn_text_value = "";
    $meta_tbtn_link_value = "";
    $meta_price_value = "";
    $meta_address_value = "";
    $meta_details_value = "";
    $meta_details_link_value = "";

    // Button One Text
    if(isset($_POST["meta-btn-text"]))
    {
        $meta_btn_text_value = $_POST["meta-btn-text"];
    }   
    update_post_meta($post_id, "meta-btn-text", $meta_btn_text_value);

    // Button One Link
    if(isset($_POST["meta-btn-link"]))
    {
        $meta_btn_link_value = $_POST["meta-btn-link"];
    }   
    update_post_meta($post_id, "meta-btn-link", $meta_btn_link_value);

    // Button Two Text
    if(isset($_POST["meta-tbtn-text"]))
    {
        $meta_tbtn_text_value = $_POST["meta-tbtn-text"];
    }   
    update_post_meta($post_id, "meta-tbtn-text", $meta_tbtn_text_value);

    // Button Two Link
    if(isset($_POST["meta-tbtn-link"]))
    {
        $meta_tbtn_link_value = $_POST["meta-tbtn-link"];
    }   
    update_post_meta($post_id, "meta-tbtn-link", $meta_tbtn_link_value);

    // Price
    if(isset($_POST["meta-price"]))
    {
        $meta_price_value = $_POST["meta-price"];
    }   
    update_post_meta($post_id, "meta-price", $meta_price_value);

    // Address
    if(isset($_POST["meta-address"]))
    {
        $meta_address_value = $_POST["meta-address"];
    }   
    update_post_meta($post_id, "meta-address", $meta_address_value);

    // Details
    if(isset($_POST["meta-details"]))
    {
        $meta_details_value = $_POST["meta-details"];
    }   
    update_post_meta($post_id, "meta-details", $meta_details_value);

    // Details Link
    if(isset($_POST["meta-details-link"]))
    {
        $meta_details_link_value = $_POST["meta-details-link"];
    }   
    update_post_meta($post_id, "meta-details-link", $meta_details_link_value);

}

add_action("save_post", "save_custom_meta_box", 10, 3);


// Video Custom Fields
function add_custom_videos_meta_box()
{
    add_meta_box("demo-meta-box", "Custom Meta Box", "custom_videos_meta_box_markup", "videos", "side", "high", null);
}

add_action("add_meta_boxes", "add_custom_videos_meta_box");

function custom_videos_meta_box_markup($object)
{
    wp_nonce_field(basename(__FILE__), "meta-box-nonce");

    ?>
      <div>
        <label for="meta-video-link">Video Link</label>
        <input name="meta-video-link" type="text" value="<?php echo get_post_meta($object->ID, "meta-video-link", true); ?>">
        <br>
      </div>
      
    <?php  
}

function save_videos_meta_box($post_id, $post, $update)
{
    if (!isset($_POST["meta-box-nonce"]) || !wp_verify_nonce($_POST["meta-box-nonce"], basename(__FILE__)))
        return $post_id;

    if(!current_user_can("edit_post", $post_id))
        return $post_id;

    if(defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
        return $post_id;

    $slug = "videos";
    if($slug != $post->post_type)
        return $post_id;

    $meta_video_link = "";

    // Button One Text
    if(isset($_POST["meta-video-link"]))
    {
        $meta_video_link = $_POST["meta-video-link"];
    }   
    update_post_meta($post_id, "meta-video-link", $meta_video_link);

}

add_action("save_post", "save_videos_meta_box", 10, 3);

// Testimonial Custom Fields
function add_custom_testimonial_meta_box()
{
    add_meta_box("demo-meta-box", "Custom Meta Box", "custom_testimonial_meta_box_markup", "testimonial", "side", "high", null);
}

add_action("add_meta_boxes", "add_custom_testimonial_meta_box");

function custom_testimonial_meta_box_markup($object)
{
    wp_nonce_field(basename(__FILE__), "meta-box-nonce");

    ?>
      <div>
        <label for="meta-author-address">Author Address</label>
        <input name="meta-author-address" type="text" value="<?php echo get_post_meta($object->ID, "meta-author-address", true); ?>">
        <br>
      </div>
      
    <?php  
}

function save_testimonial_meta_box($post_id, $post, $update)
{
    if (!isset($_POST["meta-box-nonce"]) || !wp_verify_nonce($_POST["meta-box-nonce"], basename(__FILE__)))
        return $post_id;

    if(!current_user_can("edit_post", $post_id))
        return $post_id;

    if(defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
        return $post_id;

    $slug = "testimonial";
    if($slug != $post->post_type)
        return $post_id;

    $meta_author_address = "";

    // Button One Text
    if(isset($_POST["meta-author-address"]))
    {
        $meta_author_address = $_POST["meta-author-address"];
    }   
    update_post_meta($post_id, "meta-author-address", $meta_author_address);

}

add_action("save_post", "save_testimonial_meta_box", 10, 3);