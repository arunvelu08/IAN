<?php
/*
 * The sidebar containing the main widget area.
 * Author & Copyright: iangreen
 * URL: https://iangreen.com/
 */

global $iangreen_redux_options;
$iangreen_blog_widget = (isset($iangreen_redux_options['blog_widget'])) ? $iangreen_redux_options['blog_widget'] : '';

?>
<div class="iangn-secondary">
	<?php if (!is_page() && $iangreen_blog_widget && !is_single()) {
		if (is_active_sidebar($iangreen_blog_widget)) {
			dynamic_sidebar($iangreen_blog_widget);
		}
	} else {
		if (is_active_sidebar('sidebar-1')) {
			dynamic_sidebar( 'sidebar-1' );
		}
	} ?>
</div><!-- #secondary -->
<?php
