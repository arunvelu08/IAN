<?php
/*
 * The template for displaying all single posts.
 * Author & Copyright: iangreen
 * URL: https://iangreen.com/
 */
get_header();
?>
<div id="iangn-content" class="iangn-mid-wrap iangn-post-single right-sidebar">
	<div class="container">
    <div class="row">
      <div class="iangn-primary">
        <div class="iangn-unit-fix">
					<?php
					if ( have_posts() ) :
						/* Start the Loop */
						while ( have_posts() ) : the_post();
							get_template_part( 'template-parts/post/content', 'single' );
							if ( comments_open() || get_comments_number() ) :
			          comments_template();
			        endif;
						endwhile;
					else :
						get_template_part( 'template-parts/post/content', 'none' );
					endif; ?>
				</div><!-- unit-fix -->
			</div><!-- layout -->
			<?php
				get_sidebar(); // Sidebar
			?>
		</div><!-- row -->
	</div><!-- container -->
</div><!-- mid -->
<?php
get_footer();
