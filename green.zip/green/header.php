<?php
/*
 * The header for our theme.
 * Author & Copyright: iangreen
 * URL: https://iangreen.com/
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="profile" href="//gmpg.org/xfn/11">
<?php
wp_head();
?>
</head>
<body <?php body_class(); ?>>
<?php iangreen_wp_body_open(); ?>
<!-- Full Page -->
<!-- iangreen Main Wrap -->
<div class="iangn-main-wrap">
  <a class="skip-link screen-reader-text" href="#iangn-content"><?php esc_html_e( 'Skip to content', 'iangreen' ); ?></a>
  <!-- iangreen Main Wrap Inner -->
  <div class="main-wrap-inner">
  <!-- Header -->
  <header class="iangn-header">
    <?php get_template_part( 'template-parts/header/logo' ); ?>
    <div class="iangn-header-right">
      <?php get_template_part( 'template-parts/header/menu', 'bar' ); ?>
    </div>
  </header>
  <?php
