<?php
/*
 * The template for displaying 404 pages (not found).
 * Author & Copyright: iangreen
 * URL: https://iangreen.com/
 */

get_header();
?>
<div class="iangn-error">
  <div class="container">
    <h1 class="error-title"><?php echo esc_html__( '404', 'iangreen' ); ?></h1>
    <h2 class="error-subtitle"><?php echo esc_html__( 'Ooops!!! Something went Wrong', 'iangreen' ); ?></h2>
    <p><?php echo esc_html__( 'The page you are looking for is removed or might never existed.', 'iangreen' ); ?></p>
    <div class="iangn-btn-wrap"><a href="<?php echo esc_url(home_url( '/' )); ?>" class="iangn-btn iangn-blue-btn iangn-small-btn"><?php echo esc_html__( 'BACK TO HOME', 'iangreen' ); ?></a></div>
  </div>
</div>
<?php
get_footer();
